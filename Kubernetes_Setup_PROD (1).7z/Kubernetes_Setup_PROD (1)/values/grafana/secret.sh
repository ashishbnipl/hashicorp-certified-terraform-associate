#!/bin/bash
kubectl create namespace fnc-grafana

kubectl create secret generic grafana-admin --from-file=./admin-password --from-file=./admin-user -n fnc-grafana

# dump existing secret
kubectl get secret cpmapi-secret -n fme-cpm -o yaml > grafana-secret.yaml
# alter secret offline

# load secret for https wildcard
kubectl apply -f grafana-secret.yaml -n fnc-grafana

# install grafana
helm install grafana stable/grafana -n fnc-grafana --values values.yaml

# upgade grafana
helm upgrade grafana stable/grafana -n fnc-grafana --values values.yaml