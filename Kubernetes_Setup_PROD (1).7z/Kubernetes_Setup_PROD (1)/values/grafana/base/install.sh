# install grafana
helm install grafana grafana/grafana -n grafana --values values.yaml

# upgrade
helm upgrade grafana grafana/grafana -n grafana --values values.yaml