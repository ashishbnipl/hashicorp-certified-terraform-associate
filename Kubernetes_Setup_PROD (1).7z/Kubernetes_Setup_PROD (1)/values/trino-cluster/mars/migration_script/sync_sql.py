# from presto.dbapi import connect
# from presto.auth import BasicAuthentication
# from presto.exceptions import PrestoUserError

from trino.dbapi import connect as connect2
from trino.auth import BasicAuthentication as BasicAuthentication2

from dotenv import load_dotenv

import os
from pathlib import Path
import glob
import os
import re

"""
from sqlalchemy import create_engine

from sqlalchemy.schema import Table, MetaData
from sqlalchemy.sql.expression import select, text

engine = create_engine('trino://lb4770@localhost:443/system')

connection = engine.connect()
rows = connection.execute(text("SELECT * FROM runtime.nodes")).fetchall()



# or using SQLAlchemy schema

nodes = Table(
    'nodes',
    MetaData(schema='runtime'),
    autoload=True,
    autoload_with=engine
)

rows = connection.execute(select(nodes)).fetchall()
"""


def dump_tabdefs(conn, schema, targetdir):
    cur = conn.cursor()

    cur.execute("SHOW TABLES FROM "+schema)
    tables = cur.fetchall()

    for table in tables:
        print(table)
        c2 = conn.cursor()
        tabdef = ""
        try:
            c2.execute(f"SHOW CREATE TABLE \"{table[0]}\"")
            sql = c2.fetchall()
            print(sql[0][0])
            tabdef = sql[0][0]
        except Exception as ex:
            print("seems like a view", ex)
            c2.execute(f"SHOW CREATE VIEW \"{table[0]}\"")
            sql = c2.fetchall()
            tabdef = sql[0][0]

        with open(os.path.join(targetdir, table[0].replace('/', '_')+".sql"), "w") as text_file:
            text_file.write(tabdef)


def deploy_tabdefs(conn, catalog, schema, targetdir):
    rgx = re.compile("$\w*CREATE\w+VIEW", flags=re.IGNORECASE)
    cur = conn.cursor()

    for f in glob.glob(targetdir+"/*.sql"):
        bn = os.path.basename(f)
        bn = bn.removesuffix(".sql")
        print("--", f, bn)
        txt = Path(f).read_text()
        typ = "TABLE"

        #if not rgx.match(txt) == None: #
        if "create view" in txt.lower():
            typ = "VIEW"

        print(f"DROP {typ} IF EXISTS {catalog}.{schema}.{bn}\n;\n\n")
        print(txt)

        cur.execute(txt)
        try:
            sql = cur.fetchall()
            print(sql[0][0])
        except Exception as ex:
            print("can not create table", ex)
        


def trino(cmd, url, schema, catalog):
    load_dotenv()
    if os.environ.get('TRINO_USER') == None:
        raise ValueError("please set TRINO_USER in the environment or via .env file")
    if os.environ.get('TRINO_PASSWORD') == None:
        raise ValueError("please set TRINO_PASSWORD in the environment or via .env file")

    targetdir = ".data/trino/"+catalog+"/"+schema
    Path(targetdir).mkdir(parents=True, exist_ok=True)

    conn = connect2(
        host=url,
        port="443",
        auth=BasicAuthentication2(os.environ['TRINO_USER'], os.environ['TRINO_PASSWORD']),
        http_scheme="https",
        catalog=catalog,
        schema=schema)

    if cmd == 'pull':
        dump_tabdefs(conn, schema, targetdir)
    elif cmd == 'push':
        deploy_tabdefs(conn, catalog, schema, targetdir)
    else:
        raise ValueError("command not known, should be pull or push")


if __name__ == "__main__":
    #export old
    # trino("pull", "trino.fac.intra.fresenius.com", "kabi_emvsalerts_i67", "hive")
    # trino("pull", "trino.fac.intra.fresenius.com", "kabi_emvsalerts_p67", "hive")
    # trino("pull", "trino.fac.intra.fresenius.com", "kabi_planisware_dev", "hive")
    # trino("pull", "trino.fac.intra.fresenius.com", "kabi_planisware_prod", "hive")
    # trino("pull", "trino.fac.intra.fresenius.com", "kabi_mars", "hive")
    # trino("pull", "trino.fac.intra.fresenius.com", "kabi_sapbw_p92", "hive")

    #push to new
    trino("push", "trino.mars.intra.fresenius.com", "kabi_emvsalerts_i67", "hive")
    trino("push", "trino.mars.intra.fresenius.com", "kabi_emvsalerts_p67", "hive")
    trino("push", "trino.mars.intra.fresenius.com", "kabi_planisware_dev", "hive")
    trino("push", "trino.mars.intra.fresenius.com", "kabi_planisware_prod", "hive")
    trino("push", "trino.mars.intra.fresenius.com", "kabi_mars", "hive")
    trino("push", "trino.mars.intra.fresenius.com", "kabi_sapbw_p92", "hive")
