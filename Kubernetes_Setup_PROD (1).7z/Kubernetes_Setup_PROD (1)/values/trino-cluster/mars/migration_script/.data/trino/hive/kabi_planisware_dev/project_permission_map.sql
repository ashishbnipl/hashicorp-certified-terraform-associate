CREATE VIEW hive.kabi_planisware_dev."project_permission_map" SECURITY DEFINER AS
SELECT
  a.internal_number
, a.exported_date
, b.permissions_split
FROM
  (project_permissions a
CROSS JOIN UNNEST(SPLIT(project_permissions, ',')) b (permissions_split))