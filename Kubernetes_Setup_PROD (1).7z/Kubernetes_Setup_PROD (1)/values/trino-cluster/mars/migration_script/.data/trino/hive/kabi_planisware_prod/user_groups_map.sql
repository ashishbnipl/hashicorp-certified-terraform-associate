CREATE VIEW hive.kabi_planisware_prod."user_groups_map" SECURITY DEFINER AS
SELECT
  a.name
, a.email_address
, t.group_split
FROM
  (hive.kabi_planisware_prod.user_list a
CROSS JOIN UNNEST(SPLIT(groups_list, ',')) t (group_split))