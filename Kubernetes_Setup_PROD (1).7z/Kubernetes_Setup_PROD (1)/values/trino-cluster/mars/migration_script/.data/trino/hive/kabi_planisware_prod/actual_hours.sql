CREATE TABLE hive.kabi_planisware_prod.actual_hours (
   acth_fc_2 double,
   acth_latest_approval double,
   cost_center_key varchar(10000),
   cost_account_key varchar(10000),
   month bigint,
   reporting_unit_key varchar(10000),
   year bigint,
   workpackage varchar(10000),
   acth_fc_3 double,
   actual_hours_onb double,
   acth double,
   project_onb bigint,
   acth_fc_0 double
)
WITH (
   external_location = 's3a://kabi-planisware-prod/actual_hours',
   format = 'PARQUET'
)