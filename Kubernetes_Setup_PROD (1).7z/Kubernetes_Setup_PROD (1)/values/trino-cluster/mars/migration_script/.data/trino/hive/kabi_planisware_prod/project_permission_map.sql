CREATE VIEW hive.kabi_planisware_prod."project_permission_map" SECURITY DEFINER AS
SELECT
  a.project_onb
, b.permissions_split
FROM
  (hive.kabi_planisware_prod.project_permissions a
CROSS JOIN UNNEST(SPLIT(project_permissions, ',')) b (permissions_split))