CREATE VIEW hive.kabi_emvsalerts_p67."ppu_dim" SECURITY DEFINER AS
WITH
  b1 AS (
   SELECT
     regexp_replace(f.bic_fk_mat, '\s', '') material_number
   , f.bic_fk_ppunit ppu
   , bic_fk_msourc multisourcing
   FROM
     hive.kabi_sapbw_p92.bic_pfk_mat f
   WHERE ((soursystem = 'P1') AND (objvers = 'A'))
) 
, b2 AS (
   SELECT
     material_number
   , ppu
   , multisourcing
   , count(*) OVER (PARTITION BY material_number) cnt_uniq
   , row_number() OVER (PARTITION BY material_number ORDER BY ppu DESC) rnk_uniq
   FROM
     b1
) 
SELECT
  material_number
, ppu
, multisourcing
FROM
  b2
WHERE (rnk_uniq = 1)