CREATE TABLE hive.kabi_planisware_dev.mapping_projects (
   project_onb varchar,
   program varchar
)
WITH (
   csv_separator = ';',
   external_location = 's3a://kabi-planisware-prod/mapping/project_program_mapping',
   format = 'CSV',
   skip_header_line_count = 1
)