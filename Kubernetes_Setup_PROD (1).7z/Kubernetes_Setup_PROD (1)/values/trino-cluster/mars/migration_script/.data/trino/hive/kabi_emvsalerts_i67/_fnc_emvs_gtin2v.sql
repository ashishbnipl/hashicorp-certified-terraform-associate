CREATE TABLE hive.kabi_emvsalerts_i67."/fnc/emvs_gtin2v" (
   product_id varchar(40),
   gtin varchar(14),
   coding_scheme varchar(4),
   name varchar(255),
   common_name varchar(255),
   pharma_form varchar(70),
   strength varchar(50),
   pack_type varchar(50),
   pack_size bigint,
   gtin_guid_c32 varchar(32),
   target_market_iso varchar(2),
   national_code varchar(20),
   art57_code varchar(60),
   mah_guid varchar(32)
)
WITH (
   external_location = 's3a://kabi-emvsalerts-i67/FNC_EMVS_GTIN2V',
   format = 'PARQUET'
)