CREATE VIEW hive.kabi_planisware_prod."nut_analytics_npv" SECURITY DEFINER AS
SELECT
  project_onb
, value
FROM
  hive.kabi_planisware_prod.npv_item
WHERE ("type" = U&'NPV (k\20AC)')