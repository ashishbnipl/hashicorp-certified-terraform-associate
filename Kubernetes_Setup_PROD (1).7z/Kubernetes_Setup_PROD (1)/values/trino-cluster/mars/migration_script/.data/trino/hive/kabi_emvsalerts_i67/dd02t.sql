CREATE TABLE hive.kabi_emvsalerts_i67.dd02t (
   tabname varchar(30),
   ddlanguage varchar(2),
   as4local varchar(1),
   as4vers varchar(4),
   ddtext varchar(60)
)
WITH (
   external_location = 's3a://kabi-emvsalerts-i67/DD02T',
   format = 'PARQUET'
)