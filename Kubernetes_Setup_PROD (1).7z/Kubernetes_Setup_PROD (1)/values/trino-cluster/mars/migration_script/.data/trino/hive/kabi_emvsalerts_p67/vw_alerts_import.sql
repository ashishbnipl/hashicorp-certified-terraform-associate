CREATE VIEW hive.kabi_emvsalerts_p67."vw_alerts_import" SECURITY DEFINER AS
SELECT
  mandt
, corrid_alert
, flag_current
, flag_current_previous
, flag_current_previous_txt
, flag_12_month
, CAST(timestamp AS varchar(24)) timestamp
, CAST(alert_timestamp AS varchar(24)) alert_timestamp
, code
, uniquealertid
, message_txt
, source
, serial_no
, business_process
, return_code
, ext_trans_id
, corrid
, product_code
, product_schema
, targetmarket
, CAST(expirydate AS varchar(10)) expirydate
, batch_id
, reporting_account
, alert_msg_id
, erp_material
, erp_batch
, sn_in_oer
, ext_status
, remedy
, CAST(remdate AS varchar(10)) remdate
, remtime
, remname
, remprog
, CAST(crdate AS varchar(10)) crdate
, crtime
, crname
, crprog
, CAST(chdate AS varchar(10)) chdate
, chtime
, chname
, chprog
, clientid
, manual_entry
, market_id
, product_name
, CAST(stored_expirydate AS varchar(10)) stored_expirydate
, stored_batch_id
, support_code
, CAST(support_date AS varchar(10)) support_date
, support_time
, error_message
, crdate_part
, product_id
, gtin
, coding_scheme
, name
, common_name
, pharma_form
, strength
, pack_type
, pack_size
, gtin_guid_c32
, landgu
, short_text
, product_guid
, shtext_large
, bb_batch
, product_id_blank
, ppu
, multisourcing
FROM
  vw_alerts