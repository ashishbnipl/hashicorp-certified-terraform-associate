CREATE TABLE hive.kabi_planisware_prod.project_permissions (
   project_permissions varchar(10000),
   project_onb bigint
)
WITH (
   external_location = 's3a://kabi-planisware-prod/project_permissions',
   format = 'PARQUET'
)