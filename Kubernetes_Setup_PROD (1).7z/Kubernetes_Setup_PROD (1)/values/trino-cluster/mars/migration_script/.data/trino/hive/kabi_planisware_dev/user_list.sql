CREATE TABLE hive.kabi_planisware_dev.user_list (
   name varchar(10000),
   email_address varchar(10000),
   groups_list varchar(10000)
)
WITH (
   external_location = 's3a://kabi-planisware-dev/user_list',
   format = 'PARQUET'
)