CREATE TABLE hive.kabi_planisware_dev.cost_units (
   unit_name varchar(10000),
   unit_value double
)
WITH (
   external_location = 's3a://kabi-planisware-dev/cost_units',
   format = 'PARQUET'
)