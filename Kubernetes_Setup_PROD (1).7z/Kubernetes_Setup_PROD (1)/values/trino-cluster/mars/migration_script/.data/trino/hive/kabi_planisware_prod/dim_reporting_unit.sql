CREATE VIEW hive.kabi_planisware_prod."dim_reporting_unit" SECURITY DEFINER AS
SELECT
  "key" reporting_unit_key
, "name" reporting_unit_name
FROM
  hive.kabi_planisware_prod.obs_export
WHERE is_reporting_unit