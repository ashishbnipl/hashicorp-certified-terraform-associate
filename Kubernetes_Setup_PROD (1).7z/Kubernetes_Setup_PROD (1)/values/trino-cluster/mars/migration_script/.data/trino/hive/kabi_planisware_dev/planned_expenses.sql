CREATE TABLE hive.kabi_planisware_dev.planned_expenses (
   project_onb bigint,
   planned_expenditure_onb bigint,
   workpackage varchar(10000),
   cost_center_key varchar(10000),
   cost_account_key varchar(10000),
   vendor varchar(10000),
   year bigint,
   month bigint,
   le double,
   le_fc_2 double,
   le_fc_3 double,
   le_latest_approval double,
   eac_latest_approval double,
   reporting_unit_key varchar(10000),
   le_fc_0 double
)
WITH (
   external_location = 's3a://kabi-planisware-dev/planned_expenses',
   format = 'PARQUET'
)