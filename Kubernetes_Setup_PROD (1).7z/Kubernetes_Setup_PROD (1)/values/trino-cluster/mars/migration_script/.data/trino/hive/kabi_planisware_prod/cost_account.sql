CREATE TABLE hive.kabi_planisware_prod.cost_account (
   cost_account_key varchar(10000),
   cost_account varchar(10000),
   cost_type varchar(10000)
)
WITH (
   external_location = 's3a://kabi-planisware-prod/cost_account',
   format = 'PARQUET'
)