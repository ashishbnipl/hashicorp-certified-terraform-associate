CREATE VIEW hive.kabi_planisware_dev."nut_analytics_sales" SECURITY DEFINER AS
SELECT
  onb project_onb
, start_date
, value sales
, min_start
, (year(start_date) = (year(min_start) + 2)) is_y_3
FROM
  ((
   SELECT
     (CASE WHEN (onb1 IS NOT NULL) THEN onb1 ELSE onb2 END) onb
   , (CASE WHEN (sd1 IS NOT NULL) THEN sd1 ELSE sd2 END) start_date
   , (CASE WHEN ("current" IS NOT NULL) THEN "current" ELSE initial END) value
   FROM
     ((
      SELECT
        internal_number onb1
      , start_date sd1
      , value current
      FROM
        hive.kabi_planisware_dev.npv_item
      WHERE (("type" = 'Incremental - Total Net sales') AND (version = 'Current'))
   ) 
   FULL JOIN (
      SELECT
        internal_number onb2
      , start_date sd2
      , value initial
      FROM
        hive.kabi_planisware_dev.npv_item
      WHERE (("type" = 'Incremental - Total Net sales') AND (version = 'Initial'))
   )  ON ((onb1 = onb2) AND (sd1 = sd2)))
) 
LEFT JOIN (
   SELECT
     internal_number
   , min(start_date) min_start
   FROM
     hive.kabi_planisware_dev.npv_item
   WHERE (("type" = 'Incremental - Total Net sales') AND (value IS NOT NULL))
   GROUP BY internal_number
)  ON (onb = internal_number))