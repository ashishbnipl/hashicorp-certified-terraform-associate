CREATE VIEW hive.kabi_planisware_prod."dim_workpackage" SECURITY DEFINER AS
SELECT DISTINCT workpackage
FROM
  hive.kabi_planisware_prod.fact_financial