CREATE TABLE hive.kabi_planisware_prod.project_details (
   real_start date,
   real_finish date,
   reporting_lead_business_unit varchar(10000),
   project_sub_type varchar(10000),
   bu_department varchar(10000),
   parent_sbs varchar(10000),
   portfolio_range varchar(10000),
   project_onb bigint,
   approval_status varchar(10000),
   sales_to_safeguard double,
   total_score double,
   project_id varchar(10000),
   project_name varchar(10000),
   responsible_department varchar(10000),
   sales_year_3_score varchar(10000),
   gross_margin_score varchar(10000),
   strategic_fit_score double,
   time_to_market_score varchar(10000),
   complexity_score varchar(10000)
)
WITH (
   external_location = 's3a://kabi-planisware-prod/project_details',
   format = 'PARQUET'
)