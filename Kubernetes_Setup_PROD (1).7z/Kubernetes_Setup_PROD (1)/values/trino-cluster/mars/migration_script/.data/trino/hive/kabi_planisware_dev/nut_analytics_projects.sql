CREATE VIEW hive.kabi_planisware_dev."nut_analytics_projects" SECURITY DEFINER AS
SELECT
  project_onb
, project_id
, project_name
, parent_sbs
, le
, sales_to_safeguard
, score
FROM
  ((
   SELECT *
   FROM
     hive.kabi_planisware_dev.project_details
   WHERE ((reporting_lead_business_unit = 'BU Nutrition') AND (parent_sbs IN ('EN', 'PN', 'Keto')))
) 
LEFT JOIN (
   SELECT
     project_onb onb1
   , sum(latest) le
   FROM
     hive.kabi_planisware_dev.fact_financial
   WHERE (("source" <> 'actual_expenses') AND (project_onb IN (SELECT project_onb
FROM
  hive.kabi_planisware_dev.project_details
WHERE ((reporting_lead_business_unit = 'BU Nutrition') AND (parent_sbs IN ('EN', 'PN', 'Keto')) AND (portfolio_range IN ('MR Yes', 'MR Yes Adaption')))
)))
   GROUP BY project_onb
)  ON (project_onb = onb1))