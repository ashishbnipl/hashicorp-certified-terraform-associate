CREATE VIEW hive.kabi_planisware_dev."fact_financial" SECURITY DEFINER AS
SELECT
  project_onb
, unique_onb
, cost_account_key
, cost_center_key
, reporting_unit_key
, workpackage
, CAST(concat(concat(concat(CAST(year AS varchar), '-'), CAST(month AS varchar)), '-01') AS date) ref_date
, (unit_value * act) latest
, null latest_approval
, null fc_0
, null fc_2
, null fc_3
, vendor
, sap_po_number
, sap_po_position_description
, sap_co_text
, sap_ref_doc_number
, 'actual_expenses' source
FROM
  (
   SELECT
     project_onb
   , actual_expenditure_onb unique_onb
   , cost_account_key
   , cost_center_key
   , reporting_unit_key
   , workpackage
   , month
   , year
   , cost_unit
   , unit_value
   , act
   , vendor
   , sap_po_number
   , sap_po_position_description
   , sap_co_text
   , sap_ref_doc_number
   FROM
     (hive.kabi_planisware_dev.actual_expenses_new
   LEFT JOIN (
      SELECT
        unit_name
      , unit_value
      FROM
        hive.kabi_planisware_prod.cost_units
   )  ON (cost_unit = unit_name))
) 
UNION ALL SELECT
  project_onb
, actual_hours_onb unique_onb
, cost_account_key
, cost_center_key
, reporting_unit_key
, workpackage
, CAST(concat(concat(concat(CAST(year AS varchar), '-'), CAST(month AS varchar)), '-01') AS date) ref_date
, acth latest
, acth_latest_approval latest_approval
, acth_fc_0 fc_0
, acth_fc_2 fc_2
, acth_fc_3 fc_3
, null vendor
, null sap_po_number
, null sap_po_position_description
, null sap_co_text
, null sap_ref_doc_number
, 'actual_hours' source
FROM
  hive.kabi_planisware_dev.actual_hours
UNION ALL SELECT
  project_onb
, planned_expenditure_onb unique_onb
, cost_account_key
, cost_center_key
, reporting_unit_key
, workpackage
, CAST(concat(concat(concat(CAST(year AS varchar), '-'), CAST(month AS varchar)), '-01') AS date) ref_date
, le latest
, le_latest_approval latest_approval
, le_fc_0 fc_0
, le_fc_2 fc_2
, le_fc_3 fc_3
, vendor
, null sap_po_number
, null sap_po_position_description
, null sap_co_text
, null sap_ref_doc_number
, 'planned_expenses' source
FROM
  hive.kabi_planisware_dev.planned_expenses
UNION ALL SELECT
  project_onb
, planned_hours_onb unique_onb
, cost_account_key
, cost_center_key
, reporting_unit_key
, workpackage
, CAST(concat(concat(concat(CAST(year AS varchar), '-'), CAST(month AS varchar)), '-01') AS date) ref_date
, le latest
, le_latest_approval latest_approval
, le_fc_0 fc_0
, le_fc_2 fc_2
, le_fc_3 fc_3
, null vendor
, null sap_po_number
, null sap_po_position_description
, null sap_co_text
, null sap_ref_doc_number
, 'planned_hours' source
FROM
  hive.kabi_planisware_dev.planned_hours