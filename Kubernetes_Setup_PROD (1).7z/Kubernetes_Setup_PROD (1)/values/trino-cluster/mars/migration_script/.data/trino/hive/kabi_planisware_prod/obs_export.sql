CREATE TABLE hive.kabi_planisware_prod.obs_export (
   key varchar(10000),
   name varchar(10000),
   is_cost_center boolean,
   is_reporting_unit boolean
)
WITH (
   external_location = 's3a://kabi-planisware-prod/obs_export',
   format = 'PARQUET'
)