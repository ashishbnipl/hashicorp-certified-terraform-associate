CREATE TABLE hive.kabi_planisware_dev.activities (
   planned_start date,
   planned_finish date,
   actual_start date,
   actual_finish date,
   latest_approval_start date,
   latest_approval_finish date,
   workpackage varchar(10000),
   key_milestone boolean,
   launch_milestone boolean,
   activity_onb bigint,
   cost_account_key varchar(10000),
   project_onb bigint,
   ms_description varchar(10000),
   exported_date date
)
WITH (
   external_location = 's3a://kabi-planisware-dev/activities',
   format = 'PARQUET'
)