CREATE VIEW hive.kabi_planisware_dev."user_groups_map" SECURITY DEFINER AS
SELECT
  a.name
, a.email_address
, a.exported_date
, t.group_split
FROM
  (hive.kabi_planisware_dev.user_list a
CROSS JOIN UNNEST(SPLIT(groups_list, ',')) t (group_split))