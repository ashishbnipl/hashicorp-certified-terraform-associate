CREATE VIEW hive.kabi_planisware_dev."dim_reporting_unit" SECURITY DEFINER AS
SELECT
  "key" reporting_unit_key
, "name" reporting_unit_name
FROM
  hive.kabi_planisware_dev.obs_export
WHERE is_reporting_unit