CREATE TABLE hive.kabi_emvsalerts_p67.remedy_dim (
   remedy_key varchar,
   remedy_name varchar
)
WITH (
   csv_separator = ';',
   external_location = 's3a://kabi-emvsalerts-p67/remedy_dim',
   format = 'CSV',
   skip_header_line_count = 1
)