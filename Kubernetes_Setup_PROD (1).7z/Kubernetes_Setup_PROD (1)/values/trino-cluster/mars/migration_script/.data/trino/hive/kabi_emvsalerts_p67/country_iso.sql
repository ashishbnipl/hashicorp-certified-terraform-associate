CREATE TABLE hive.kabi_emvsalerts_p67.country_iso (
   country_iso_code varchar,
   country varchar
)
WITH (
   csv_separator = ';',
   external_location = 's3a://kabi-emvsalerts-p67/country_ISO',
   format = 'CSV',
   skip_header_line_count = 1
)