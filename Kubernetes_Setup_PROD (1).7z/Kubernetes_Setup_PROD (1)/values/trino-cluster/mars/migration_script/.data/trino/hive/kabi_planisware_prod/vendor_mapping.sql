CREATE TABLE hive.kabi_planisware_prod.vendor_mapping (
   sap varchar,
   fips varchar
)
WITH (
   csv_separator = ';',
   external_location = 's3a://kabi-planisware-prod/mapping/vendor_mapping',
   format = 'CSV',
   skip_header_line_count = 1
)