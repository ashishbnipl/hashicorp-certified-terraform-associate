CREATE VIEW hive.kabi_emvsalerts_p67."material_dim" SECURITY DEFINER AS
SELECT DISTINCT
  c.material_number
, COALESCE(d.short_text, e.short_text) material
, COALESCE(d.langu, e.langu) langu
FROM
  (((
   SELECT DISTINCT
     client
   , product_id
   , regexp_replace(product_id, '^[0]+', '') material_number
   , product_guid
   FROM
     hive.kabi_emvsalerts_p67.comv_pr_shtext
)  c
LEFT JOIN hive.kabi_emvsalerts_p67.comv_pr_shtext d ON ((c.product_ID = d.product_id) AND (d.langu = 'E')))
LEFT JOIN hive.kabi_emvsalerts_p67.comv_pr_shtext e ON ((c.Product_ID = e.PRODUCT_ID) AND (e.LANGU = 'D')))