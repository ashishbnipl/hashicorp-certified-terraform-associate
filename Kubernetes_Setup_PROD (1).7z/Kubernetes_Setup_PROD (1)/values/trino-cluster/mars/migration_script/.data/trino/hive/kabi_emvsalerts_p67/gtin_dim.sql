CREATE VIEW hive.kabi_emvsalerts_p67."gtin_dim" SECURITY DEFINER AS
SELECT DISTINCT
  regexp_replace(b.product_id, '^[0]+', '') material_number
, b.gtin
, b.coding_scheme product_schema
, b.common_name
, b.pharma_form
, b.strength
, b.pack_type
, b.pack_size
FROM
  hive.kabi_emvsalerts_p67."/fnc/emvs_gtin2v" b