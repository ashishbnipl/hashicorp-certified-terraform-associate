CREATE TABLE hive.kabi_mars.ffb_targets (
   day varchar(1000),
   startofhour varchar(1000),
   target varchar(1000),
   hour_no varchar(1000),
   day_no varchar(1000),
   sp_filename varchar(1000),
   sp_created_at varchar(1000),
   sp_updated_at varchar(1000)
)
WITH (
   external_location = 's3a://kabi-mars/ffb_targets',
   format = 'PARQUET'
)