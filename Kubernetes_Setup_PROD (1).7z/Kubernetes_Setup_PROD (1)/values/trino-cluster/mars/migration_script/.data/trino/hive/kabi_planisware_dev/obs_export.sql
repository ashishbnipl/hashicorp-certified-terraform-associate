CREATE TABLE hive.kabi_planisware_dev.obs_export (
   key varchar(10000),
   name varchar(10000),
   is_cost_center boolean,
   is_reporting_unit boolean
)
WITH (
   external_location = 's3a://kabi-planisware-dev/obs_export',
   format = 'PARQUET'
)