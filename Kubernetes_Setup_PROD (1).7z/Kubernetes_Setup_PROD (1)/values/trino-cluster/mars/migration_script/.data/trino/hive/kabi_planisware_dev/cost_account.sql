CREATE TABLE hive.kabi_planisware_dev.cost_account (
   cost_account_key varchar(10000),
   cost_account varchar(10000),
   cost_type varchar(10000)
)
WITH (
   external_location = 's3a://kabi-planisware-dev/cost_account',
   format = 'PARQUET'
)