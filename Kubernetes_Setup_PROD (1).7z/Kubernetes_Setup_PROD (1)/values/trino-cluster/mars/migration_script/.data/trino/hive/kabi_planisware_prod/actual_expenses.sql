CREATE TABLE hive.kabi_planisware_prod.actual_expenses (
   project_onb bigint,
   actual_expenditure_onb bigint,
   workpackage varchar(10000),
   reporting_unit_key varchar(10000),
   cost_center_key varchar(10000),
   cost_account_key varchar(10000),
   vendor varchar(10000),
   year bigint,
   month bigint,
   start_date date,
   end_date date,
   cost_unit varchar(10000),
   act double,
   sap_doc_item bigint,
   sap_po_position_description varchar(10000),
   sap_vendor_number bigint,
   sap_vendor_description varchar(10000),
   sap_po_description varchar(10000),
   sap_posting_date date,
   sap_ref_doc_number bigint,
   sap_po_number varchar(10000),
   sap_co_text varchar(10000)
)
WITH (
   external_location = 's3a://kabi-planisware-prod/actual_expenses',
   format = 'PARQUET'
)