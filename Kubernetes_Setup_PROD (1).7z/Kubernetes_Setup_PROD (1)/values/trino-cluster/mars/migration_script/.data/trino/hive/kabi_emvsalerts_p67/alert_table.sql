CREATE VIEW hive.kabi_emvsalerts_p67."alert_table" SECURITY DEFINER AS
SELECT
  a.uniquealertid
, a.serial_no
, a.product_code gtin
, a.alert_msg_id xml_message_id
, a.product_schema
, a.targetmarket
, a.stored_batch_id
, a.erp_batch
, a.batch_id
, (CASE WHEN (a.market_id = '') THEN 'Blank' ELSE a.market_id END) scanning_market
, CAST(a.expirydate AS varchar(10)) expirydate
, (CASE WHEN (a.stored_batch_id <> '') THEN a.stored_batch_id WHEN (a.erp_batch <> '') THEN a.erp_batch ELSE a.batch_id END) bb_batch
, a.reporting_account
, a.erp_material
, a.sn_in_oer
, a.ext_status
, CAST(a.remdate AS varchar(10)) remdate
, a.remedy
, a.remname
, CAST(a.crdate AS varchar(10)) crdate
, a.clientid
, CAST(a.stored_expirydate AS varchar(10)) expirydate_stored
, a.support_code error_code
, a.error_message
FROM
  hive.kabi_emvsalerts_p67.fnc_emvs_alerts a
WHERE (a.REPORTING_ACCOUNT = 'FK')