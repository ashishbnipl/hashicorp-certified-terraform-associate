CREATE TABLE hive.kabi_planisware_prod.planned_hours (
   le_fc_2 double,
   cost_account_key varchar(10000),
   planned_hours_onb double,
   le_latest_approval double,
   reporting_unit_key varchar(10000),
   le_fc_3 double,
   workpackage varchar(10000),
   month bigint,
   year bigint,
   le double,
   project_onb bigint,
   cost_center_key varchar(10000),
   le_fc_0 double
)
WITH (
   external_location = 's3a://kabi-planisware-prod/planned_hours',
   format = 'PARQUET'
)