CREATE VIEW hive.kabi_planisware_prod."nut_analytics_projects" SECURITY DEFINER AS
SELECT
  project_onb
, project_id
, project_name
, parent_sbs
, (CASE WHEN (project_sub_type = 'Project.PRODUCT_MTCE.GLOBAL_ROLL_OUT_WO_DEV') THEN 'GRO' WHEN (project_sub_type = 'Project.PRODUCT_MTCE.DES_REL_UPD') THEN 'LCM' WHEN (project_sub_type = 'Project.PRODUCT_MTCE.REG_REL_MTCE') THEN 'LCM' WHEN (project_sub_type = 'Project.PRODUCT_MTCE.QUAL_REL_MTCE') THEN 'LCM' WHEN (project_sub_type = 'Project.PRODUCT_MTCE.PROC_EFF_REL_PRJ') THEN 'LCM' WHEN (project_sub_type = 'Project.PRODUCT_MTCE.SOURCING_RELATED_MAINT') THEN 'LCM' WHEN (project_sub_type = 'Project.R_AND_D.INT_FIN_PRD_DEV_AND_PRD') THEN 'NPD' WHEN (project_sub_type = 'Project.R_AND_D.GLOBAL_ROLL_OUT') THEN 'NPD' WHEN (project_sub_type = 'Project.R_AND_D.HYBRID_PROJECT') THEN 'NPD' ELSE '' END) project_type
, le
, sales_to_safeguard
, total_score
, CAST(sales_year_3_score AS int) sales_year_3_score
, CAST(gross_margin_score AS int) gross_margin_score
, strategic_fit_score
, CAST(time_to_market_score AS int) time_to_market_score
, CAST(complexity_score AS int) complexity_score
, (CASE WHEN ((sales_year_3_score IS NULL) OR (gross_margin_score IS NULL) OR (complexity_score IS NULL)) THEN 0 ELSE 1 END) score_complete
FROM
  ((
   SELECT *
   FROM
     hive.kabi_planisware_prod.project_details
   WHERE ((reporting_lead_business_unit = 'BU Nutrition') AND (parent_sbs IN ('EN', 'PN', 'Keto')) AND (project_sub_type <> 'Project.Lumpsum.Lumpsum'))
) 
LEFT JOIN (
   SELECT
     project_onb onb1
   , sum(latest) le
   FROM
     hive.kabi_planisware_prod.fact_financial
   WHERE (("source" <> 'actual_expenses') AND (project_onb IN (SELECT project_onb
FROM
  hive.kabi_planisware_prod.project_details
WHERE ((reporting_lead_business_unit = 'BU Nutrition') AND (parent_sbs IN ('EN', 'PN', 'Keto')) AND (portfolio_range IN ('MR Yes', 'MR Yes Adaption')))
)))
   GROUP BY project_onb
)  ON (project_onb = onb1))