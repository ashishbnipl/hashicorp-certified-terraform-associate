CREATE VIEW hive.kabi_planisware_prod."fact_activities" SECURITY DEFINER AS
SELECT
  project_onb
, ms_description
, planned_start
, latest_approval_start
, kms_rank
, type
, (EXTRACT(DAY FROM (planned_start - latest_approval_start)) / 30) plan_vs_appr
, (EXTRACT(DAY FROM (planned_start - latest_approval_start)) / 30) plan_vs_appr_dup
, (CASE WHEN (EXTRACT(DAY FROM (planned_start - latest_approval_start)) > 0) THEN EXTRACT(DAY FROM (planned_start - current_date)) ELSE 0 END) days_to_ms
, ' ' spacer
FROM
  (
   SELECT
     *
   , null kms_rank
   , 'First Launch' type
   FROM
     hive.kabi_planisware_prod.activities
   WHERE ((latest_approval_start IS NOT NULL) AND (planned_start > exported_date) AND (launch_milestone = true))
UNION ALL    SELECT
     *
   , Rank() OVER (PARTITION BY project_onb ORDER BY planned_start ASC) kms_rank
   , concat('KMS', CAST(Rank() OVER (PARTITION BY project_onb ORDER BY planned_start ASC) AS varchar)) type
   FROM
     hive.kabi_planisware_prod.activities
   WHERE ((latest_approval_start IS NOT NULL) AND (planned_start > exported_date) AND (launch_milestone = false) AND key_milestone)
)