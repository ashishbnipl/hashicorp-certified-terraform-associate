CREATE VIEW hive.kabi_planisware_dev."dim_cost_center" SECURITY DEFINER AS
SELECT
  "key" cost_center_key
, "name" cost_center_name
FROM
  hive.kabi_planisware_dev.obs_export
WHERE is_cost_center