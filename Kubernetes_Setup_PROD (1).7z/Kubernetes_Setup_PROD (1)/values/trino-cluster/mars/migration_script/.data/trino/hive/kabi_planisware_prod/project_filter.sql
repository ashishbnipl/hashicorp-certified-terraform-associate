CREATE VIEW hive.kabi_planisware_prod."project_filter" SECURITY DEFINER AS
(
(
(
         SELECT
           CAST(project_onb AS bigint) project_onb
         , program name
         , '' parent_sbs
         , 'BioPharma' bu
         FROM
           hive.kabi_planisware_prod.mapping_projects
      ) UNION ALL (
         SELECT
           project_onb
         , (CASE WHEN (project_sub_type = 'Project.PRODUCT_MTCE.GLOBAL_ROLL_OUT_WO_DEV') THEN 'GRO' WHEN (project_sub_type = 'Project.PRODUCT_MTCE.DES_REL_UPD') THEN 'LCM' WHEN (project_sub_type = 'Project.PRODUCT_MTCE.REG_REL_MTCE') THEN 'LCM' WHEN (project_sub_type = 'Project.PRODUCT_MTCE.QUAL_REL_MTCE') THEN 'LCM' WHEN (project_sub_type = 'Project.PRODUCT_MTCE.PROC_EFF_REL_PRJ') THEN 'LCM' WHEN (project_sub_type = 'Project.PRODUCT_MTCE.SOURCING_RELATED_MAINT') THEN 'LCM' WHEN (project_sub_type = 'Project.R_AND_D.INT_FIN_PRD_DEV_AND_PRD') THEN 'NPD' WHEN (project_sub_type = 'Project.R_AND_D.GLOBAL_ROLL_OUT') THEN 'NPD' WHEN (project_sub_type = 'Project.R_AND_D.HYBRID_PROJECT') THEN 'NPD' END) name
         , parent_sbs
         , 'Nutrition' bu
         FROM
           hive.kabi_planisware_prod.project_details
         WHERE ((project_sub_type IN ('Project.PRODUCT_MTCE.GLOBAL_ROLL_OUT_WO_DEV', 'Project.PRODUCT_MTCE.DES_REL_UPD', 'Project.PRODUCT_MTCE.REG_REL_MTCE', 'Project.PRODUCT_MTCE.QUAL_REL_MTCE', 'Project.PRODUCT_MTCE.PROC_EFF_REL_PRJ', 'Project.PRODUCT_MTCE.SOURCING_RELATED_MAINT', 'Project.R_AND_D.INT_FIN_PRD_DEV_AND_PRD', 'Project.R_AND_D.GLOBAL_ROLL_OUT', 'Project.R_AND_D.HYBRID_PROJECT')) AND (reporting_lead_business_unit = 'BU Nutrition') AND (parent_sbs IN ('EN', 'PN', 'Keto')) AND (portfolio_range IN ('MR Yes', 'MR Yes Adaption')))
      )    ) UNION ALL (
      SELECT
        project_onb
      , bu_department name
      , '' parent_sbs
      , 'Generics' bu
      FROM
        hive.kabi_planisware_prod.project_details
      WHERE ((reporting_lead_business_unit = 'BU Generics and IV Fluids') AND (bu_department IN ('Gx DC Brazil', 'Gx DC China', 'Gx I&DC EU', 'Gx I&DC IN', 'Gx I&DC US', 'Gx Maint AP', 'Gx Maint EU', 'Gx Maint US', 'Gx Standard i.V. Fluids')))
   ) )