CREATE VIEW hive.kabi_planisware_dev."nut_analytics_npv" SECURITY DEFINER AS
SELECT
  internal_number
, value
FROM
  hive.kabi_planisware_dev.npv_item
WHERE ("type" = U&'NPV (k\20AC)')