CREATE VIEW hive.kabi_planisware_dev."dim_workpackage" SECURITY DEFINER AS
SELECT DISTINCT workpackage
FROM
  hive.kabi_planisware_dev.fact_financial