CREATE VIEW hive.kabi_planisware_dev."fact_activities" SECURITY DEFINER AS
SELECT
  project_onb
, ms_description
, planned_start
, latest_approval_start
, null kms_rank
, (EXTRACT(DAY FROM (planned_start - latest_approval_start)) / 30) plan_vs_appr
, 'First Launch' type
FROM
  hive.kabi_planisware_dev.activities
WHERE ((latest_approval_start IS NOT NULL) AND (planned_start > exported_date) AND (launch_milestone = true))
UNION ALL SELECT
  project_onb
, ms_description
, planned_start
, latest_approval_start
, Rank() OVER (PARTITION BY project_onb ORDER BY planned_start ASC) kms_rank
, (EXTRACT(DAY FROM (planned_start - latest_approval_start)) / 30) plan_vs_appr
, concat('KMS', CAST(Rank() OVER (PARTITION BY project_onb ORDER BY planned_start ASC) AS varchar)) type
FROM
  hive.kabi_planisware_dev.activities
WHERE ((latest_approval_start IS NOT NULL) AND (planned_start > exported_date) AND (launch_milestone = false) AND key_milestone)