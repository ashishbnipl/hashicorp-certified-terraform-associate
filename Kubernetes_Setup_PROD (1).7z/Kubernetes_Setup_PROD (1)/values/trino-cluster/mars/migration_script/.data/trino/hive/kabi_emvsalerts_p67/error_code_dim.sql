CREATE TABLE hive.kabi_emvsalerts_p67.error_code_dim (
   error_code varchar,
   error_code_description varchar
)
WITH (
   csv_separator = ';',
   external_location = 's3a://kabi-emvsalerts-p67/error_code_dim',
   format = 'CSV',
   skip_header_line_count = 1
)