CREATE TABLE hive.kabi_planisware_dev.project_details (
   real_start date,
   real_finish date,
   reporting_lead_business_unit varchar(10000),
   project_sub_type varchar(10000),
   bu_department varchar(10000),
   parent_sbs varchar(10000),
   portfolio_range varchar(10000),
   project_onb bigint,
   approval_status varchar(10000),
   sales_to_safeguard double,
   score double,
   project_id varchar(10000),
   project_name varchar(10000)
)
WITH (
   external_location = 's3a://kabi-planisware-dev/project_details',
   format = 'PARQUET'
)