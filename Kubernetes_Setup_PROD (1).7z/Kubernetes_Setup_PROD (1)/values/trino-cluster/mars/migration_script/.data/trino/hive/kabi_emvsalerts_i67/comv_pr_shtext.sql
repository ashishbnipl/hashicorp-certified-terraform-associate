CREATE TABLE hive.kabi_emvsalerts_i67.comv_pr_shtext (
   client varchar(3),
   product_guid varchar(32),
   langu varchar(2),
   shtext_large varchar(40),
   short_text varchar(40),
   product_id varchar(40),
   config varchar(1),
   xnosearch varchar(1)
)
WITH (
   external_location = 's3a://kabi-emvsalerts-i67/COMV_PR_SHTEXT',
   format = 'PARQUET'
)