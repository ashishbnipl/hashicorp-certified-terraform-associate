CREATE TABLE hive.kabi_emvsalerts_i67.dd03t (
   tabname varchar(30),
   ddlanguage varchar(2),
   as4local varchar(1),
   fieldname varchar(30),
   ddtext varchar(60)
)
WITH (
   external_location = 's3a://kabi-emvsalerts-i67/DD03T',
   format = 'PARQUET'
)