CREATE VIEW hive.kabi_emvsalerts_p67."alert_analysis" SECURITY DEFINER AS
SELECT
  b.*
, (CASE WHEN (COALESCE(b."scanned_batch_not_eq", "serial_no_not_len_14", "serial_no_not_numeric", "serial_not_in_oer", "scanned_expirydate_not_matched", "scanning_country_not_equal_to_market_ID", "double_scan", "double_scan_pack_inactive", "serial_no_not_len_14") IS NULL) THEN 'X' ELSE null END) "further_investigation_needed"
FROM
  (
   SELECT
     a.alert_msg_id xml_message_id
   , (CASE WHEN ((a.support_code IN ('A2', 'A3', 'NMVS_NC_PC_02', 'NMVS_FE_LOT_03', 'A68', 'NMVS_FE_LOT_13')) AND ((CASE WHEN (a.stored_batch_id = '') THEN a.erp_batch ELSE a.stored_batch_id END) <> a.batch_id)) THEN 'X' ELSE null END) "scanned_batch_not_eq"
   , (CASE WHEN (a.support_code IN ('A2', 'A3', 'NMVS_NC_PC_02', 'NMVS_FE_LOT_03', 'A68', 'NMVS_FE_LOT_13')) THEN (CASE WHEN (substr(a.serial_no, 1, 1) = '-') THEN 'X' ELSE (CASE WHEN (length(a.serial_no) >= 18) THEN (CASE WHEN ((TRY_CAST(substr(a.serial_no, 1, 10) AS bigint) IS NULL) OR (TRY_CAST(substr(a.serial_no, 10, (length(a.serial_no) - 10)) AS bigint) IS NULL) OR (substr(a.serial_no, 10, 1) = '-')) THEN 'y' ELSE null END) ELSE (CASE WHEN (TRY_CAST(a.serial_no AS bigint) IS NULL) THEN 'X' ELSE null END) END) END) END) "serial_no_not_numeric"
   , (CASE WHEN ((a.support_code IN ('A2', 'A3', 'NMVS_NC_PC_02', 'NMVS_FE_LOT_03', 'A68', 'NMVS_FE_LOT_13')) AND (a.sn_in_oer <> 'X')) THEN 'X' ELSE null END) "serial_not_in_oer"
   , (CASE WHEN ((a.support_code IN ('A52', 'NMVS_FE_LOT_12')) AND (a.stored_expirydate <> a.expirydate)) THEN 'X' ELSE null END) "scanned_expirydate_not_matched"
   , (CASE WHEN ((a.support_code IN ('NMVS_NC_PCK_19')) AND ((substring(a.uniquealertid, 1, 2) <> a.targetmarket) OR (substring(a.uniquealertid, 1, 2) <> a.market_id))) THEN 'X' ELSE null END) "scanning_country_not_equal_to_market_ID"
   , (CASE WHEN (a.support_code IN ('A7')) THEN 'X' ELSE null END) "double_scan"
   , (CASE WHEN (a.support_code IN ('A24', 'NMVS_NC_PCK_22', 'NMVS_NC_PCK_27')) THEN 'X' ELSE null END) "double_scan_pack_inactive"
   , (CASE WHEN ((a.support_code IN ('A2', 'A3', 'NMVS_NC_PC_02', 'NMVS_FE_LOT_03', 'A68', 'NMVS_FE_LOT_13')) AND (length(a.serial_no) <> 14)) THEN (CASE WHEN ((a.sn_in_oer = 'X') AND (length(a.serial_no) = 12)) THEN null ELSE 'X' END) ELSE null END) "serial_no_not_len_14"
   FROM
     hive.kabi_emvsalerts_p67.fnc_emvs_alerts a
   WHERE (a.reporting_account = 'FK')
)  b