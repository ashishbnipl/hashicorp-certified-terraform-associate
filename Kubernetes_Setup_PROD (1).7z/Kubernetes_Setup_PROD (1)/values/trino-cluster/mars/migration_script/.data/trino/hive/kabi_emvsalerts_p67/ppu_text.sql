CREATE TABLE hive.kabi_emvsalerts_p67.ppu_text (
   ppu varchar,
   plant_name varchar
)
WITH (
   csv_separator = ';',
   external_location = 's3a://kabi-emvsalerts-p67/ppu_text',
   format = 'CSV',
   skip_header_line_count = 1
)