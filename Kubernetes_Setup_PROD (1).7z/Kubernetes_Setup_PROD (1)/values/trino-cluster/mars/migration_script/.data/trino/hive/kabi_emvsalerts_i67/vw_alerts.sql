CREATE VIEW hive.kabi_emvsalerts_i67."vw_alerts" SECURITY DEFINER AS
WITH
  b AS (
   SELECT DISTINCT
     PRODUCT_ID
   , GTIN
   , CODING_SCHEME
   , NAME
   , COMMON_NAME
   , PHARMA_FORM
   , STRENGTH
   , PACK_TYPE
   , PACK_SIZE
   , GTIN_GUID_C32
   FROM
     "/fnc/emvs_gtin2v"
) 
, replaced AS (
   SELECT
     a.*
   , b.*
   , COALESCE(c.LANGU, d.LANGU) LANDGU
   , COALESCE(c.SHORT_TEXT, d.SHORT_TEXT) SHORT_TEXT
   , COALESCE(c.PRODUCT_GUID, d.PRODUCT_GUID) PRODUCT_GUID
   , COALESCE(c.SHTEXT_LARGE, d.SHTEXT_LARGE) SHTEXT_LARGE
   , COALESCE(a.STORED_BATCH_ID, a.ERP_BATCH, a.BATCH_ID) BB_BATCH
   , regexp_replace(b.PRODUCT_ID, '^[0]+', '') PRODUCT_ID_BLANK
   , (CASE WHEN (year(a.crdate) = year(current_date)) THEN 1 ELSE 0 END) flag_current
   , (CASE WHEN (year(a.crdate) = year(current_date)) THEN 1 WHEN (year(a.crdate) = (year(current_date) - 1)) THEN 0 ELSE null END) flag_current_previous
   , (CASE WHEN (year(a.crdate) = year(current_date)) THEN '1' WHEN (year(a.crdate) = (year(current_date) - 1)) THEN '0' ELSE '' END) flag_current_previous_txt
   FROM
     (((fnc_emvs_alerts a
   LEFT JOIN b ON (a.PRODUCT_CODE = b.GTIN))
   LEFT JOIN comv_pr_shtext c ON ((b.Product_ID = c.PRODUCT_ID) AND (c.LANGU = 'E')))
   LEFT JOIN comv_pr_shtext d ON ((b.Product_ID = d.PRODUCT_ID) AND (d.LANGU = 'D')))
   WHERE (a.REPORTING_ACCOUNT = 'FK')
) 
SELECT
  replaced.*
, m.bic_fk_ppunit PPU
, m.bic_fk_msourc MULTISOURCING
FROM
  (replaced
LEFT JOIN hive.kabi_sapbw_p92.bic_pfk_mat m ON ((replaced.product_ID_blank = m.bic_fk_mat) AND (m.soursystem = 'P1')))