CREATE TABLE hive.kabi_planisware_dev.npv_item (
   start_date date,
   end_date date,
   value double,
   version varchar(10000),
   type varchar(10000),
   project_onb bigint,
   file varchar(10000)
)
WITH (
   external_location = 's3a://kabi-planisware-dev/npv_item',
   format = 'PARQUET'
)