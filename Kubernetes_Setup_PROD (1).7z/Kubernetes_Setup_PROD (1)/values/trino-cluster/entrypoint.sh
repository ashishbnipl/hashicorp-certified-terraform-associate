#!/bin/sh

cd /opt/trino/bin
./launcher start

# Keep the container running and this my friend is a hack :-) because k8s cannot directly shutdown trino but will wait for graceperiod seconds until it is killed off
tail -f /dev/null