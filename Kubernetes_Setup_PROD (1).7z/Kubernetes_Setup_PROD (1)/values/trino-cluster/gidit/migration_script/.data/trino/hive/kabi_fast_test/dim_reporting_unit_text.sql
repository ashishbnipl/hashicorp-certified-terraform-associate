CREATE TABLE hive.kabi_fast_test.dim_reporting_unit_text (
   dim_reporting_unit varchar,
   reporting_unit_name varchar,
   data_available integer
)
WITH (
   external_location = 's3a://fast/presto/test/dim_reporting_unit_text',
   format = 'PARQUET'
)