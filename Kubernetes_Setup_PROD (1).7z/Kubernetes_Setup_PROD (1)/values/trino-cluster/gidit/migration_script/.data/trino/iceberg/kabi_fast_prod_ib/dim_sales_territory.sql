CREATE TABLE iceberg.kabi_fast_prod_ib.dim_sales_territory (
   dim_sales_territory varchar,
   sales_territory_text varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-prod/iceberg/dim_sales_territory-8ec6fd4001844f6987150d02ccef2aff'
)