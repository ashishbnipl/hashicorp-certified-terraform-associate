CREATE VIEW iceberg.kabi_fast_qual_ib."vw_act" SECURITY DEFINER AS
WITH
  tab_act AS (
   SELECT
     vw_fact_act_bu.dim_reporting_unit
   , vw_fact_act_bu.dim_date
   , vw_fact_act_bu.dim_measure
   , vw_fact_act_bu.dim_material
   , vw_fact_act_bu.dim_version
   , vw_fact_act_bu.dim_local_currency
   , vw_fact_act_bu.dim_destination
   , vw_fact_act_bu.dim_reporting_category
   , vw_fact_act_bu.dim_source_system
   , vw_fact_act_bu.dim_sales_channel
   , vw_fact_act_bu.dim_sales_territory
   , vw_fact_act_bu.kpi
   , ps.dim_type
   , ps.max_act_month_scenario
   , ps.dim_month
   , EXTRACT(YEAR FROM vw_fact_act_bu.dim_date) dim_year
   , ps.dim_view
   FROM
     ("iceberg"."kabi_fast_qual_ib"."mvw_fact_act_bu" vw_fact_act_bu
   INNER JOIN "iceberg"."kabi_fast_qual_ib"."vw_period_setting" ps ON ((vw_fact_act_bu.dim_version = ps.dim_version) AND (vw_fact_act_bu.dim_month = ps.dim_month) AND (vw_fact_act_bu.dim_lag = ps.dim_lag)))
   WHERE ((1 = 1) AND (EXTRACT(YEAR FROM vw_fact_act_bu.dim_date) >= 2021))
) 
SELECT *
FROM
  tab_act