CREATE TABLE hive.kabi_fast_prod.raw_dim_destination (
   dim_destination varchar,
   destination_name varchar
)
WITH (
   format = 'PARQUET'
)