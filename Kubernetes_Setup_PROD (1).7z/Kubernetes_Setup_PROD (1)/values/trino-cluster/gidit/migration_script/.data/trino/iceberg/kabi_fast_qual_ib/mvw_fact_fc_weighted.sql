CREATE TABLE iceberg.kabi_fast_qual_ib.mvw_fact_fc_weighted (
   dim_reporting_unit varchar,
   dim_date date,
   dim_year bigint,
   dim_measure varchar,
   dim_material varchar,
   dim_local_currency varchar,
   dim_version varchar,
   dim_lag bigint,
   dim_month bigint,
   dim_last_act_str varchar,
   dim_last_act date,
   dim_destination varchar,
   dim_sales_territory varchar,
   dim_sales_channel varchar,
   dim_source_system varchar,
   dim_reporting_category varchar,
   kpi double,
   max_dim_last_act date
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/mvw_fact_fc_weighted__dbt_tmp-8b959e5b96024659b7102c1f119564bb'
)