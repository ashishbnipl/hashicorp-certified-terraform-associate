CREATE VIEW iceberg.kabi_fast_prod_ib."vw_dim_material" SECURITY DEFINER AS
SELECT DISTINCT
  trim(BOTH FROM dim_material) dim_material
, trim(BOTH FROM material_name) material_name
, l3
, l4
, l5
, l6
, l7
, l8
, l9
, l3_name
, l4_name
, l5_name
, l6_name
, l7_name
, l8_name
, l9_name
FROM
  "iceberg"."kabi_fast_prod_ib"."dim_material"