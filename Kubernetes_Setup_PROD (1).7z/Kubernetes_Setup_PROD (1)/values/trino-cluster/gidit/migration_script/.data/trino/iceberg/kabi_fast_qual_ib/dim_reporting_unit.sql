CREATE TABLE iceberg.kabi_fast_qual_ib.dim_reporting_unit (
   dim_reporting_unit varchar,
   reporting_unit_name varchar,
   dim_region varchar,
   region_name varchar,
   dim_sub_region_1 varchar,
   sub_region_1_name varchar,
   dim_sub_region_2 varchar,
   sub_region_2_name varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/dim_reporting_unit-4a6e2dd9f8d9496f98de744eca3a2fc0'
)