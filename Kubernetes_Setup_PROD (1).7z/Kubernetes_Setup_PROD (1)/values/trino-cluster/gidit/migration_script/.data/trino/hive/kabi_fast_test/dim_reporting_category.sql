CREATE TABLE hive.kabi_fast_test.dim_reporting_category (
   dim_reporting_category varchar,
   reporting_category_name varchar
)
WITH (
   external_location = 's3a://fast/presto/test/dim_reporting_category',
   format = 'PARQUET'
)