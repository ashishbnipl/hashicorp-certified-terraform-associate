CREATE TABLE iceberg.kabi_fast_qual_ib.mvw_fact_restricted_pred (
   dim_reporting_unit varchar,
   dim_date date,
   dim_year bigint,
   dim_measure varchar,
   dim_material varchar,
   dim_local_currency varchar,
   dim_version varchar,
   dim_lag bigint,
   dim_month bigint,
   dim_last_act date,
   dim_destination varchar,
   dim_reporting_category varchar,
   dim_source_system varchar,
   dim_sales_territory varchar,
   dim_sales_channel varchar,
   kpi double,
   max_dim_last_act date
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/mvw_fact_restricted_pred__dbt_tmp-d991b75b220f473ba42b3a6df22017dd'
)