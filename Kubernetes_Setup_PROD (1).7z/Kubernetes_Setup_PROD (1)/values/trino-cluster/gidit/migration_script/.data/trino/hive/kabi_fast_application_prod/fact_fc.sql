CREATE TABLE hive.kabi_fast_application_prod.fact_fc (
   dim_date date,
   dim_measure varchar,
   dim_estimation varchar,
   dim_local_currency varchar,
   dim_version varchar,
   kpi double,
   dim_last_act date,
   dim_reporting_unit varchar
)
WITH (
   external_location = 's3a://fast/presto_application/prod/fact_fc',
   format = 'PARQUET',
   partitioned_by = ARRAY['dim_reporting_unit']
)