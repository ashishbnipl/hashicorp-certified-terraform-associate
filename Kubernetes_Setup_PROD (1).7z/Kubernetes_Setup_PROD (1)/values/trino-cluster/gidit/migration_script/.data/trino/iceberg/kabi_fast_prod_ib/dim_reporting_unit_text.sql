CREATE TABLE iceberg.kabi_fast_prod_ib.dim_reporting_unit_text (
   dim_reporting_unit varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-prod/iceberg/dim_reporting_unit_text-3d44e7fcee4b4693b8c0f1e5925e9938'
)