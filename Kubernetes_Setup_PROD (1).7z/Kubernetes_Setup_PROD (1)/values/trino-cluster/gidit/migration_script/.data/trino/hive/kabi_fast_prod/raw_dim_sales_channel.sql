CREATE TABLE hive.kabi_fast_prod.raw_dim_sales_channel (
   dim_sales_channel varchar,
   sales_channel_text varchar
)
WITH (
   format = 'PARQUET'
)