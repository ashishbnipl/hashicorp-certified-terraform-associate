CREATE TABLE iceberg.kabi_fast_qual_ib.dim_reporting_unit_text (
   dim_reporting_unit varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/dim_reporting_unit_text-6cbc5d10a9694caa9d44e3133a652aca'
)