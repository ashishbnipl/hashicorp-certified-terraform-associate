CREATE TABLE hive.kabi_fast_application_prod.dim_destination (
   dim_destination varchar,
   destination_name varchar
)
WITH (
   external_location = 's3a://fast/presto_application/prod/dim_destination',
   format = 'PARQUET'
)