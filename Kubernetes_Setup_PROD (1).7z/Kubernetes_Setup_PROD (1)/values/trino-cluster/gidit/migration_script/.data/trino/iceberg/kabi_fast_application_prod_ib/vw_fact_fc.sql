CREATE VIEW iceberg.kabi_fast_application_prod_ib."vw_fact_fc" SECURITY DEFINER AS
WITH
  fact_fc AS (
   SELECT
     *
   , max(dim_last_act) OVER () max_dim_last_act
   , date_diff('month', dim_last_act, dim_date) dim_lag
   FROM
     iceberg.kabi_fast_application_prod_ib.fact_fc
   WHERE ((1 = 1) AND (EXTRACT(YEAR FROM dim_date) >= 2020))
) 
SELECT *
FROM
  fact_fc
WHERE ((EXTRACT(MONTH FROM max_dim_last_act) = EXTRACT(MONTH FROM dim_last_act)) OR ((max_dim_last_act > dim_last_act) AND (dim_lag <= 15)))