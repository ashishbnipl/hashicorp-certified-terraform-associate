CREATE TABLE hive.kabi_fast_application_prod.fact_bud23 (
   dim_measure varchar,
   dim_material varchar,
   dim_destination varchar,
   dim_reporting_category varchar,
   kpi double,
   dim_local_currency varchar,
   dim_currency_type varchar,
   dim_version varchar,
   dim_date date,
   dim_reporting_unit varchar
)
WITH (
   external_location = 's3a://fast/presto_application/prod/fact_bud23',
   format = 'PARQUET',
   partitioned_by = ARRAY['dim_reporting_unit']
)