CREATE TABLE iceberg.kabi_fast_qual_ib.mvw_batches (
   dim_model varchar,
   dim_batch varchar,
   dim_reporting_unit varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/mvw_batches__dbt_tmp-4df8a08da6684b6db92037840c778163'
)