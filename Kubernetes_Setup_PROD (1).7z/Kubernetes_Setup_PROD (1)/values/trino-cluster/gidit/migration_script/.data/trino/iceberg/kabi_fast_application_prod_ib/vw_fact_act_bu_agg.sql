CREATE VIEW iceberg.kabi_fast_application_prod_ib."vw_fact_act_bu_agg" SECURITY DEFINER AS
WITH
  bq AS (
   SELECT
     dim_date
   , dim_reporting_unit
   , dim_measure
   , dim_estimation
   , dim_local_currency
   , kpi
   FROM
     iceberg.kabi_fast_application_prod_ib.vw_fact_act_bu
   WHERE ((dim_version = 'ACT') AND (dim_local_currency <> 'GC'))
) 
, tab_agg AS (
   SELECT
     dim_date
   , dim_reporting_unit
   , dim_measure
   , dim_estimation
   , dim_local_currency
   , sum(COALESCE(kpi, 0)) kpi
   FROM
     bq
   GROUP BY dim_date, dim_reporting_unit, dim_measure, dim_estimation, dim_local_currency
) 
SELECT *
FROM
  tab_agg