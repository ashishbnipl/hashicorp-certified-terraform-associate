CREATE TABLE iceberg.kabi_fast_qual_ib.mvw_segmentation (
   dim_measure varchar,
   dim_material varchar,
   dim_destination varchar,
   dim_reporting_category varchar,
   dim_sales_territory varchar,
   dim_sales_channel varchar,
   dim_source_system varchar,
   dim_reporting_unit varchar,
   dim_local_currency varchar,
   kpi_cat_abc varchar,
   kpi_cat_xyz varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/mvw_segmentation__dbt_tmp-6ba806171f8341669bb02067f14cdb0c'
)