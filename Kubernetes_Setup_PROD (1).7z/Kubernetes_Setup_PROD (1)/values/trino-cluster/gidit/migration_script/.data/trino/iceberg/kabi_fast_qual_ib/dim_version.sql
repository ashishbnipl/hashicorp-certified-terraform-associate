CREATE TABLE iceberg.kabi_fast_qual_ib.dim_version (
   dim_version varchar,
   version_group varchar,
   version_name varchar,
   ordering integer
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/dim_version-16cca7a2d143430da65aef2ef0fd4718'
)