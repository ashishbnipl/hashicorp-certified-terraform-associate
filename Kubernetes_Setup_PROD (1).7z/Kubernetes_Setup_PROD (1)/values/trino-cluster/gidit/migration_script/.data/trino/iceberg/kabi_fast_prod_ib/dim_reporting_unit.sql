CREATE TABLE iceberg.kabi_fast_prod_ib.dim_reporting_unit (
   dim_reporting_unit varchar,
   reporting_unit_name varchar,
   dim_region varchar,
   region_name varchar,
   dim_sub_region_1 varchar,
   sub_region_1_name varchar,
   dim_sub_region_2 varchar,
   sub_region_2_name varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-prod/iceberg/dim_reporting_unit-88fa67218b004466a61bfbec7e951335'
)