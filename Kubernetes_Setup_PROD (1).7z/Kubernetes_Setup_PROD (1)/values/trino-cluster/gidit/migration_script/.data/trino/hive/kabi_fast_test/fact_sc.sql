CREATE TABLE hive.kabi_fast_test.fact_sc (
   dim_sales_channel varchar,
   sales_channel_text varchar
)
WITH (
   external_location = 's3a://fast/presto/test/fact_sc',
   format = 'PARQUET'
)