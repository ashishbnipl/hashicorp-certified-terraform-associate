CREATE TABLE hive.kabi_fast_test.ru_mapping_reporting_unit_mapping (
   dim_reporting_unit varchar(1000),
   coo_l7 varchar(1000),
   coo_l6 varchar(1000),
   coo_l5 varchar(1000),
   coo_l4 varchar(1000),
   coo_l3 varchar(1000),
   coo_l2 varchar(1000),
   coo_l1 varchar(1000),
   sp_filename varchar(1000),
   sp_created_at varchar(1000),
   sp_updated_at varchar(1000)
)
WITH (
   external_location = 's3a://fast/RU_Mapping_reporting_unit_mapping',
   format = 'PARQUET'
)