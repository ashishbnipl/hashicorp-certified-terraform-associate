CREATE VIEW iceberg.kabi_fast_application_prod_ib."vw_dim_destination" SECURITY DEFINER AS
WITH
  all_countries AS (
   SELECT
     dim_destination
   , destination_name
   FROM
     iceberg.kabi_fast_application_prod_ib.dim_destination
UNION (
      SELECT
        ''
      , 'No destination country'
      FROM
        iceberg.kabi_fast_application_prod_ib.dim_destination
      LIMIT 1
   ) ) 
, available_countries AS (
   SELECT DISTINCT dim_destination
   FROM
     iceberg.kabi_fast_application_prod_ib.fact_act_bu
) 
SELECT
  av.dim_destination
, ac.destination_name
FROM
  (available_countries av
LEFT JOIN all_countries ac ON (av.dim_destination = ac.dim_destination))