CREATE TABLE hive.kabi_fast_prod.raw_period_setting (
   dim_view varchar,
   dim_type varchar,
   dim_month integer,
   dim_version varchar,
   dim_lag integer
)
WITH (
   format = 'PARQUET'
)