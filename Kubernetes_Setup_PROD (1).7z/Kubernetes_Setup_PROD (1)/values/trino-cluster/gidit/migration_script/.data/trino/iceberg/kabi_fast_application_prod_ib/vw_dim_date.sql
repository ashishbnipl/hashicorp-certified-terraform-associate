CREATE VIEW iceberg.kabi_fast_application_prod_ib."vw_dim_date" SECURITY DEFINER AS
(
   SELECT DISTINCT
     DIM_DATE DATE_ID
   , YEAR(DIM_DATE) YEAR_INT
   , MONTH(DIM_DATE) MONTH_INT
   FROM
     iceberg.kabi_fast_application_prod_ib.vw_fact_fc
)