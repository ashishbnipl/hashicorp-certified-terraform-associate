CREATE TABLE hive.kabi_fast_test.fact_st (
   dim_sales_territory varchar,
   sales_territory_text varchar
)
WITH (
   external_location = 's3a://fast/presto/test/fact_st',
   format = 'PARQUET'
)