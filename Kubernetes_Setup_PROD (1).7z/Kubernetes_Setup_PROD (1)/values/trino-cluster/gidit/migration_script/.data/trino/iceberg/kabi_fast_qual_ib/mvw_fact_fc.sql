CREATE TABLE iceberg.kabi_fast_qual_ib.mvw_fact_fc (
   dim_date date,
   dim_measure varchar,
   dim_estimation varchar,
   dim_local_currency varchar,
   dim_version varchar,
   kpi double,
   dim_last_act date,
   dim_source_system varchar,
   dim_reporting_unit varchar,
   max_dim_last_act date,
   dim_lag bigint
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/mvw_fact_fc__dbt_tmp-69d105a3c627460aa8007e542263961a'
)