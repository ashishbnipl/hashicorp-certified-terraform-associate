CREATE TABLE iceberg.kabi_fast_prod_ib.period_setting (
   dim_view varchar,
   dim_type varchar,
   dim_month integer,
   dim_version varchar,
   dim_lag integer
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-prod/iceberg/period_setting-1bd5bd813ec2408f86aff10de7662dba'
)