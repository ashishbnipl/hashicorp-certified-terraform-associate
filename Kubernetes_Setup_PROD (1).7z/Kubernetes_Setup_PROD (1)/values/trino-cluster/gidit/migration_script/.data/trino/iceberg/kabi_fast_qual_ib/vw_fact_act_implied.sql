CREATE VIEW iceberg.kabi_fast_qual_ib."vw_fact_act_implied" SECURITY DEFINER AS
WITH
  bq AS (
   SELECT
     dat.dim_measure
   , dat.dim_material
   , dat.dim_destination
   , dat.dim_reporting_category
   , dat.dim_reporting_unit
   , dat.dim_local_currency
   , dat.dim_currency_type
   , dat.dim_version
   , dat.dim_date
   , dat.kpi
   , dat.dim_source_system
   , dat.dim_sales_channel
   , dat.dim_sales_territory
   , mat.l7 dim_estimation
   FROM
     ("iceberg"."kabi_fast_qual_ib"."fact_act_bu" dat
   LEFT JOIN "iceberg"."kabi_fast_qual_ib"."dim_material" mat ON (dat.dim_material = mat.dim_material))
   WHERE ((1 = 1) AND (EXTRACT(YEAR FROM dim_date) < 2021) AND (dim_version = 'ACT'))
) 
, bq2 AS (
   SELECT
     ru_map.dim_reporting_unit_new dim_reporting_unit
   , bq.dim_date
   , bq.dim_measure
   , bq.dim_version
   , bq.dim_destination
   , bq.dim_reporting_category
   , bq.dim_material
   , bq.dim_local_currency
   , bq.dim_currency_type
   , bq.dim_source_system
   , bq.dim_sales_channel
   , bq.dim_sales_territory
   , bq.kpi
   FROM
     (bq
   INNER JOIN "iceberg"."kabi_fast_qual_ib"."vw_fact_ru_mapping" ru_map ON ((ru_map.dim_estimation = bq.dim_estimation) AND (ru_map.dim_reporting_category = bq.dim_reporting_category) AND (ru_map.dim_destination = bq.dim_destination) AND (ru_map.dim_reporting_unit = bq.dim_reporting_unit)))
) 
SELECT
  dim_measure
, dim_material
, dim_reporting_unit
, dim_destination
, dim_reporting_category
, kpi
, dim_local_currency
, dim_currency_type
, dim_version
, dim_date
, dim_source_system
, dim_sales_territory
, dim_sales_channel
FROM
  bq2