CREATE TABLE iceberg.kabi_fast_prod_ib.mvw_fact_fc_fx (
   dim_date date,
   dim_measure varchar,
   dim_estimation varchar,
   dim_version varchar,
   dim_local_currency varchar,
   dim_lag bigint,
   dim_month bigint,
   kpi double,
   dim_reporting_unit varchar,
   dim_source_system varchar,
   dim_last_act date,
   max_dim_last_act date
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-prod/iceberg/mvw_fact_fc_fx__dbt_tmp-fd4e47387da24654800f068a2ae460f4'
)