CREATE VIEW iceberg.kabi_fast_application_prod_ib."vw_dim_local_currency" SECURITY DEFINER AS
SELECT DISTINCT
  dim_local_currency
, (CASE WHEN (dim_measure = 'NS') THEN 'Net Sales' ELSE 'Quantity' END) dim_measure
FROM
  iceberg.kabi_fast_application_prod_ib.vw_fact_act_bu