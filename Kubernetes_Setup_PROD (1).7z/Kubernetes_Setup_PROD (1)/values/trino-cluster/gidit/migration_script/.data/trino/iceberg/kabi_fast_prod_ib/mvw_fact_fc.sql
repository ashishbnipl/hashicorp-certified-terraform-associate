CREATE TABLE iceberg.kabi_fast_prod_ib.mvw_fact_fc (
   dim_date date,
   dim_measure varchar,
   dim_estimation varchar,
   dim_local_currency varchar,
   dim_version varchar,
   kpi double,
   dim_last_act date,
   dim_source_system varchar,
   dim_reporting_unit varchar,
   max_dim_last_act date,
   dim_lag bigint
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-prod/iceberg/mvw_fact_fc__dbt_tmp-d8adc8d7607946e0915132b5f7e6b816'
)