CREATE TABLE iceberg.kabi_fast_qual_ib.fact_fc (
   dim_date date,
   dim_measure varchar,
   dim_estimation varchar,
   dim_local_currency varchar,
   dim_version varchar,
   kpi double,
   dim_last_act date,
   dim_source_system varchar,
   dim_reporting_unit varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/fact_fc-f0e4e39cfd96426e8dda4475d581d0cf',
   partitioning = ARRAY['dim_reporting_unit']
)