CREATE TABLE iceberg.kabi_fast_prod_ib.mvw_fill_up (
   dim_reporting_unit varchar,
   dim_date date,
   dim_measure varchar,
   dim_material varchar,
   dim_destination varchar,
   dim_local_currency varchar,
   dim_reporting_category varchar,
   dim_source_system varchar,
   dim_sales_channel varchar,
   dim_sales_territory varchar,
   dim_view varchar,
   dim_type varchar,
   max_act_month_scenario bigint,
   dim_version varchar,
   kpi double,
   flag_pred_fill_up integer,
   dim_year bigint,
   dim_month integer
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-prod/iceberg/mvw_fill_up__dbt_tmp-67e10ec2294f48b6af2da0bb71f451b9'
)