CREATE TABLE iceberg.kabi_fast_prod_ib.mvw_fact_fy_scenarios (
   dim_material varchar,
   dim_measure varchar,
   dim_reporting_unit varchar,
   dim_local_currency varchar,
   dim_sales_channel varchar,
   dim_sales_territory varchar,
   dim_view varchar,
   dim_source_system varchar,
   dim_year bigint,
   dim_destination varchar,
   dim_reporting_category varchar,
   flag_pred_fill_up integer,
   max_act_month_scenario bigint,
   kpi_accuracy_statistical double,
   kpi_accuracy_bottom_up double,
   kpi_accuracy_actuals double,
   kpi_accuracy_statistical_inv_ytd double,
   kpi_accuracy_bottom_up_inv_ytd double,
   kpi_accuracy_actuals_inv_ytd double
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-prod/iceberg/mvw_fact_fy_scenarios__dbt_tmp-9013bd5c1de34339b2a5af81460717dc'
)