CREATE TABLE hive.kabi_fast_test.period_setting (
   dim_view varchar,
   dim_type varchar,
   dim_month integer,
   dim_version varchar,
   dim_lag integer
)
WITH (
   external_location = 's3a://fast/presto/test/period_setting',
   format = 'PARQUET'
)