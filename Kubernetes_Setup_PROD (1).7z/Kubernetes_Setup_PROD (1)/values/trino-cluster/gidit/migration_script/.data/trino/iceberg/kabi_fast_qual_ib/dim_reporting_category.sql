CREATE TABLE iceberg.kabi_fast_qual_ib.dim_reporting_category (
   dim_reporting_category varchar,
   reporting_category_name varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/dim_reporting_category-7032b1c90b0d48df938891b4871ab984'
)