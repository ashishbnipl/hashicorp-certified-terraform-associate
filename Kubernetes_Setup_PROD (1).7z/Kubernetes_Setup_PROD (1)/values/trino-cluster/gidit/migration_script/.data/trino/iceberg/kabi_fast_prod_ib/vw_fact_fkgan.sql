CREATE VIEW iceberg.kabi_fast_prod_ib."vw_fact_fkgan" SECURITY DEFINER AS
WITH
  tab_in AS (
   SELECT
     dim_reporting_unit
   , dim_date
   , dim_measure
   , dim_material
   , dim_local_currency
   , dim_last_act
   , dim_destination
   , dim_reporting_category
   , kpi
   FROM
     "iceberg"."kabi_fast_prod_ib"."mvw_fact_fc_weighted"
   WHERE (dim_source_system = 'fkgan')
) 
, tab_pred AS (
   SELECT *
   FROM
     tab_in
   WHERE (NOT (dim_reporting_unit IN (SELECT dim_reporting_unit
FROM
  vw_ru_old
)))
) 
, tab_ru2lc AS (
   SELECT DISTINCT
     dim_reporting_unit
   , dim_local_currency dim_local_currency_join
   FROM
     tab_pred
   WHERE (NOT (dim_local_currency IN ('QTY', 'GC')))
) 
, tab_seg AS (
   SELECT
     tab_pred.dim_date
   , tab_pred.dim_measure
   , tab_pred.dim_material
   , tab_pred.dim_reporting_unit
   , tab_pred.dim_local_currency
   , tab_pred.dim_destination
   , tab_pred.dim_reporting_category
   , tab_pred.dim_last_act
   , tab_pred.kpi
   , CAST(segmentation.kpi_cat_ABC AS varchar) kpi_cat_ABC
   , CAST(segmentation.kpi_cat_XYZ AS varchar) kpi_cat_XYZ
   FROM
     (tab_pred
   LEFT JOIN "iceberg"."kabi_fast_prod_ib"."mvw_segmentation" segmentation ON ((tab_pred.dim_measure = segmentation.dim_measure) AND (tab_pred.dim_material = segmentation.dim_material) AND (tab_pred.dim_destination = segmentation.dim_destination) AND (tab_pred.dim_reporting_category = segmentation.dim_reporting_category) AND (tab_pred.dim_reporting_unit = segmentation.dim_reporting_unit) AND (tab_pred.dim_local_currency = segmentation.dim_local_currency)))
) 
, tab_asp AS (
   SELECT
     tab_seg.dim_date
   , tab_seg.dim_measure
   , tab_seg.dim_material
   , tab_seg.dim_reporting_unit
   , tab_seg.dim_local_currency
   , tab_seg.dim_destination
   , tab_seg.dim_reporting_category
   , tab_seg.dim_last_act
   , tab_seg.kpi
   , tab_seg.kpi_cat_ABC
   , tab_seg.kpi_cat_XYZ
   , vw_flag_asp.flag_asp
   FROM
     (tab_seg
   LEFT JOIN "iceberg"."kabi_fast_prod_ib"."vw_flag_asp" vw_flag_asp ON ((tab_seg.dim_material = vw_flag_asp.dim_material) AND (tab_seg.dim_destination = vw_flag_asp.dim_destination) AND (tab_seg.dim_reporting_category = vw_flag_asp.dim_reporting_category) AND (tab_seg.dim_reporting_unit = vw_flag_asp.dim_reporting_unit)))
) 
, tab2write AS (
   SELECT
     tab_asp.dim_reporting_unit
   , tab_asp.dim_material
   , tab_ru2lc.dim_local_currency_join dim_local_currency
   , tab_asp.dim_destination
   , tab_asp.dim_reporting_category
   , 'LC' dim_curtype
   , concat('PRED_', upper(Date_format(tab_asp.dim_last_act, '%b'))) dim_version
   , tab_asp.dim_date
   , (CASE WHEN (tab_asp.dim_measure = 'NS') THEN 1 ELSE 0 END) flag_ns
   , (CASE WHEN (tab_asp.dim_measure = 'NS') THEN tab_asp.kpi ELSE 0 END) gross_sales
   , (CASE WHEN (tab_asp.dim_measure = 'QTY') THEN tab_asp.kpi ELSE 0 END) qty
   , tab_asp.dim_last_act
   , tab_asp.kpi_cat_ABC
   , tab_asp.kpi_cat_XYZ
   , tab_asp.flag_asp
   FROM
     (tab_asp
   INNER JOIN tab_ru2lc ON (tab_ru2lc.dim_reporting_unit = tab_asp.dim_reporting_unit))
   WHERE ((tab_asp.dim_local_currency <> 'GC') AND (tab_asp.dim_last_act > (current_date - INTERVAL  '13' MONTH)) AND (tab_asp.dim_date < (current_date + INTERVAL  '16' MONTH)))
) 
, tab_cat AS (
   SELECT
     dim_reporting_unit
   , dim_material
   , dim_local_currency
   , dim_destination
   , dim_reporting_category
   , dim_curtype
   , dim_version
   , dim_date
   , sum(gross_sales) gross_sales
   , sum(qty) qty
   , dim_last_act
   , flag_asp
   , max((CASE WHEN (flag_ns = 0) THEN kpi_cat_ABC END)) QTY_ABC
   , max((CASE WHEN (flag_ns = 0) THEN kpi_cat_XYZ END)) QTY_XYZ
   , max((CASE WHEN (flag_ns = 1) THEN kpi_cat_ABC END)) NS_ABC
   , max((CASE WHEN (flag_ns = 1) THEN kpi_cat_XYZ END)) NS_XYZ
   FROM
     tab2write
   GROUP BY dim_material, dim_reporting_unit, dim_local_currency, dim_destination, dim_reporting_category, dim_curtype, dim_version, dim_date, dim_last_act, flag_asp
) 
, tab_mat2base_uom AS (
   SELECT DISTINCT
     dim_material
   , base_uom
   FROM
     dim_material
) 
, tab_fin AS (
   SELECT
     EXTRACT(YEAR FROM base.dim_date) CALYEAR_SID
   , concat(CAST(EXTRACT(YEAR FROM base.dim_date) AS varchar), CAST(EXTRACT(QUARTER FROM base.dim_date) AS varchar)) CALQUARTER
   , EXTRACT(QUARTER FROM base.dim_date) CALQUART1
   , CAST(Date_format(base.dim_date, '%m') AS varchar) CALMONTH2
   , concat(CAST(EXTRACT(YEAR FROM base.dim_date) AS varchar), CAST(Date_format(base.dim_date, '%m') AS varchar)) CALMONTH
   , EXTRACT(YEAR FROM base.dim_date) FISCYEAR_KEY
   , 'K4' FISCVARNT
   , concat(CAST(EXTRACT(YEAR FROM base.dim_date) AS varchar), concat('0', CAST(Date_format(base.dim_date, '%m') AS varchar))) FISCPER_KEY
   , (CASE WHEN (base.dim_destination = '') THEN CAST(null AS varchar) ELSE base.dim_destination END) FKGC00029_KEY
   , base.dim_reporting_category FKGC00058_KEY
   , base.dim_curtype FKGC00101_KEY
   , base.dim_version FKGC00100_KEY
   , CAST(null AS varchar) FKGC00274_KEY
   , CAST(null AS varchar) FKGC00074_KEY
   , base.dim_reporting_unit FKGC00041_KEY
   , base.dim_material FKGC00034_KEY
   , mapping.base_uom BASE_UOM
   , base.dim_local_currency CURRENCY_KEY
   , 0 BIC_FKGK00006
   , round(sum(base.gross_sales), 2) BIC_FKGK00005
   , round(sum(base.qty), 2) BIC_FKGK00003
   , base.dim_last_act
   , base.dim_reporting_unit
   , date_format(base.dim_last_act, '%Y-%m-%d') dim_last_act_str
   , base.NS_ABC FKGC0NABC_KEY
   , base.NS_XYZ FKGC0NXYZ_KEY
   , base.QTY_ABC FKGC0QABC_KEY
   , base.QTY_XYZ FKGC0QXYZ_KEY
   , base.flag_asp FKGC00ASP_KEY
   FROM
     (tab_cat base
   INNER JOIN tab_mat2base_uom mapping ON (base.dim_material = mapping.dim_material))
   GROUP BY base.dim_reporting_unit, base.dim_material, base.dim_local_currency, base.dim_destination, base.dim_reporting_category, base.dim_curtype, base.dim_version, base.dim_date, mapping.base_uom, base.dim_last_act, base.NS_ABC, base.NS_XYZ, base.QTY_ABC, base.QTY_XYZ, base.flag_asp
) 
SELECT *
FROM
  tab_fin