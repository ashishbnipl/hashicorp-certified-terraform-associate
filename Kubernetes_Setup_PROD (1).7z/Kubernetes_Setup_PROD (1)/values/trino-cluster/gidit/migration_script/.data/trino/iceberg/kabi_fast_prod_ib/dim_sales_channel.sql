CREATE TABLE iceberg.kabi_fast_prod_ib.dim_sales_channel (
   dim_sales_channel varchar,
   sales_channel_text varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-prod/iceberg/dim_sales_channel-797e565090834a98b129b5266764c3be'
)