CREATE TABLE iceberg.kabi_fast_qual_ib.fact_bud (
   dim_measure varchar,
   dim_material varchar,
   dim_destination varchar,
   dim_reporting_category varchar,
   kpi double,
   dim_local_currency varchar,
   dim_currency_type varchar,
   dim_version varchar,
   dim_date date,
   dim_sales_channel varchar,
   dim_sales_territory varchar,
   dim_source_system varchar,
   dim_reporting_unit varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/fact_bud-8805b3089fe5446ab0b92e2c234822da',
   partitioning = ARRAY['dim_reporting_unit']
)