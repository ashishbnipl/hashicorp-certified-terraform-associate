CREATE VIEW iceberg.kabi_fast_prod_ib."vw_flag_asp" SECURITY DEFINER AS
WITH
  tab_pivot AS (
   SELECT
     max_dim_last_act
   , dim_last_act
   , dim_reporting_unit
   , dim_date
   , dim_material
   , dim_destination
   , dim_reporting_category
   , dim_sales_territory
   , dim_sales_channel
   , dim_source_system
   , max((CASE WHEN (dim_measure = 'NS') THEN kpi END)) gross_sales
   , max((CASE WHEN (dim_measure = 'QTY') THEN kpi END)) qty
   FROM
     "iceberg"."kabi_fast_prod_ib"."mvw_fact_fc_weighted"
   WHERE ((date_add('month', -12, max_dim_last_act) = dim_last_act) AND (dim_local_currency <> 'GC'))
   GROUP BY max_dim_last_act, dim_last_act, dim_reporting_unit, dim_date, dim_material, dim_destination, dim_reporting_category, dim_sales_territory, dim_sales_channel, dim_source_system
) 
, tab_asp AS (
   SELECT
     dim_last_act
   , dim_reporting_unit
   , dim_date
   , dim_material
   , dim_destination
   , dim_reporting_category
   , dim_sales_territory
   , dim_sales_channel
   , dim_source_system
   , gross_sales
   , qty
   , (gross_sales / qty) asp
   FROM
     tab_pivot
) 
, tab_asp_stat AS (
   SELECT
     dim_last_act
   , dim_reporting_unit
   , dim_material
   , dim_destination
   , dim_reporting_category
   , dim_sales_territory
   , dim_sales_channel
   , dim_source_system
   , round(max(asp), 4) asp_max
   , round(min(asp), 4) asp_min
   , round(stddev_samp(asp), 4) asp_stddev
   , round(avg(asp), 4) asp_avg
   , round((abs((max(asp) - min(asp))) / abs(stddev_samp(asp))), 4) asp_max_min
   FROM
     tab_asp
   GROUP BY dim_last_act, dim_reporting_unit, dim_material, dim_destination, dim_reporting_category, dim_sales_territory, dim_sales_channel, dim_source_system
) 
, tab_flag_asp AS (
   SELECT
     dim_last_act
   , dim_reporting_unit
   , dim_material
   , dim_destination
   , dim_reporting_category
   , dim_sales_territory
   , dim_sales_channel
   , dim_source_system
   , asp_max_min
   , asp_avg
   , asp_stddev
   , asp_max
   , asp_min
   , (CASE WHEN (asp_max_min < DECIMAL '7.5') THEN 'Y' ELSE 'N' END) flag_asp
   FROM
     tab_asp_stat
) 
SELECT *
FROM
  tab_flag_asp