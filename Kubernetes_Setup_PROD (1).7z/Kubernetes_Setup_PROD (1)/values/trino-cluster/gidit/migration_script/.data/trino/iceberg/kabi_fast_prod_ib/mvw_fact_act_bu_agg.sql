CREATE TABLE iceberg.kabi_fast_prod_ib.mvw_fact_act_bu_agg (
   dim_date date,
   dim_measure varchar,
   dim_estimation varchar,
   dim_local_currency varchar,
   dim_batch varchar,
   dim_source_system varchar,
   kpi double,
   dim_reporting_unit varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-prod/iceberg/mvw_fact_act_bu_agg__dbt_tmp-9ef8f3d2a23a46f495bde845df560e58'
)