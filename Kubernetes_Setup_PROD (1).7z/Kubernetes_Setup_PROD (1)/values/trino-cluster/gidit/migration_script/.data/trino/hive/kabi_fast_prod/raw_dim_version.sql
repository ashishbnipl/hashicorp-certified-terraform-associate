CREATE TABLE hive.kabi_fast_prod.raw_dim_version (
   dim_version varchar,
   version_group varchar,
   version_name varchar,
   ordering integer
)
WITH (
   format = 'PARQUET'
)