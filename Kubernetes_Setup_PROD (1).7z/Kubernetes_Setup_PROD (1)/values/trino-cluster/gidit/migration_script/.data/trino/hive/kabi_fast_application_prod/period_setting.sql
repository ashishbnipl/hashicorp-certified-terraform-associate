CREATE TABLE hive.kabi_fast_application_prod.period_setting (
   dim_view varchar,
   dim_type varchar,
   dim_month bigint,
   dim_version varchar,
   dim_lag bigint
)
WITH (
   external_location = 's3a://fast/presto_application/prod/period_setting',
   format = 'PARQUET'
)