CREATE TABLE hive.kabi_fast_dev.raw_dim_reporting_unit_text (
   dim_reporting_unit varchar
)
WITH (
   format = 'PARQUET'
)