CREATE VIEW iceberg.kabi_fast_application_prod_ib."vw_dim_reporting_unit" SECURITY DEFINER AS
SELECT
  DIM_REPORTING_UNIT
, REPORTING_UNIT_NAME
, DIM_REGION
, REGION_NAME
, DIM_SUB_REGION_1
, SUB_REGION_1_NAME
, DIM_SUB_REGION_2
, SUB_REGION_2_NAME
FROM
  iceberg.kabi_fast_application_prod_ib.dim_reporting_unit
WHERE ((DIM_REPORTING_UNIT IS NOT NULL) AND (DIM_REPORTING_UNIT IN (SELECT DISTINCT DIM_REPORTING_UNIT
FROM
  iceberg.kabi_fast_application_prod_ib.fact_act_bu
)))