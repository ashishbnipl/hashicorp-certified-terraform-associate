CREATE VIEW iceberg.kabi_fast_prod_ib."vw_fact_ru_mapping" SECURITY DEFINER AS
WITH
  bq AS (
   SELECT
     substring(dat.dim_reporting_unit, 1, 8) dim_reporting_unit_8
   , mat.l7 dim_estimation
   , dat.dim_version
   , dat.dim_reporting_category
   , dat.dim_destination
   , dat.dim_reporting_unit
   , count(*) cnt
   , sum(dat.kpi) kpi
   FROM
     ("iceberg"."kabi_fast_prod_ib"."fact_act_bu" dat
   LEFT JOIN "iceberg"."kabi_fast_prod_ib"."dim_material" mat ON (dat.dim_material = mat.dim_material))
   WHERE ((dat.dim_version IN ('ACT', 'ACTSC1')) AND (dat.dim_date = date('2022-01-01')) AND (dat.dim_currency_type = 'LC') AND (dat.dim_measure = 'NS'))
   GROUP BY substring(dat.dim_reporting_unit, 1, 8), mat.l7, dat.dim_reporting_category, dat.dim_destination, dat.dim_version, dat.dim_reporting_unit
   HAVING (sum(kpi) > 0)
   ORDER BY substring(dat.dim_reporting_unit, 1, 8) ASC, mat.l7 ASC, dat.dim_reporting_category ASC, dat.dim_destination ASC, dat.dim_reporting_unit ASC
) 
, tab_map AS (
   SELECT
     dim_reporting_unit_8
   , dim_reporting_category
   , dim_destination
   , dim_estimation
   , max((CASE WHEN (dim_version = 'ACT') THEN dim_reporting_unit END)) dim_reporting_unit_new
   , max((CASE WHEN (dim_version = 'ACTSC1') THEN dim_reporting_unit END)) dim_reporting_unit
   , sum((CASE WHEN (dim_version = 'ACT') THEN kpi END)) kpi_new
   , sum((CASE WHEN (dim_version = 'ACTSC1') THEN kpi END)) kpi_old
   , ((round(sum((CASE WHEN (dim_version = 'ACTSC1') THEN kpi END))) = round(sum((CASE WHEN (dim_version = 'ACT') THEN kpi END)))) AND (count(*) = 2)) flag_unique_mapping
   , count(*) cnt
   FROM
     bq
   GROUP BY dim_reporting_unit_8, dim_destination, dim_reporting_category, dim_estimation
) 
SELECT
  dim_estimation
, dim_reporting_category
, dim_destination
, dim_reporting_unit_new
, dim_reporting_unit
FROM
  tab_map
WHERE flag_unique_mapping