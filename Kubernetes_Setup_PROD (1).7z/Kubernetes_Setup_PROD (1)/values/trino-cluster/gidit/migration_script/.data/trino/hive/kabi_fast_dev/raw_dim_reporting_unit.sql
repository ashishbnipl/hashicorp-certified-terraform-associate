CREATE TABLE hive.kabi_fast_dev.raw_dim_reporting_unit (
   dim_reporting_unit varchar,
   reporting_unit_name varchar,
   dim_region varchar,
   region_name varchar,
   dim_sub_region_1 varchar,
   sub_region_1_name varchar,
   dim_sub_region_2 varchar,
   sub_region_2_name varchar
)
WITH (
   format = 'PARQUET'
)