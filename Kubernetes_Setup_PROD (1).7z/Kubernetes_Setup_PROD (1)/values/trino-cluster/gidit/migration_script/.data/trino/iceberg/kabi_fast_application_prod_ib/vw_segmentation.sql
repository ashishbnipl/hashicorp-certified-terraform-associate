CREATE VIEW iceberg.kabi_fast_application_prod_ib."vw_segmentation" SECURITY DEFINER AS
WITH
  bq_base AS (
   SELECT
     EXTRACT(YEAR FROM dim_date) dim_year
   , *
   FROM
     iceberg.kabi_fast_application_prod_ib.vw_fact_act_bu
) 
, bq AS (
   SELECT
     dim_year
   , dim_material
   , dim_destination
   , dim_reporting_category
   , dim_reporting_unit
   , sum(kpi) kpi
   , (stddev_samp(kpi) / avg(kpi)) kpi_cv
   FROM
     bq_base
   WHERE ((dim_version = 'ACT') AND (dim_measure = 'NS') AND (dim_year > 2020))
   GROUP BY dim_year, dim_material, dim_destination, dim_reporting_category, dim_reporting_unit
   HAVING (sum(kpi) > 0)
) 
, tab_ru AS (
   SELECT
     dim_year
   , dim_reporting_unit
   , dim_destination
   , dim_reporting_category
   , sum(kpi) kpi
   FROM
     bq
   GROUP BY dim_year, dim_reporting_unit, dim_destination, dim_reporting_category
) 
, tab_rel AS (
   SELECT
     bq.*
   , (bq.kpi / tab_ru.kpi) kpi_rel
   FROM
     (bq
   LEFT JOIN tab_ru ON ((tab_ru.dim_reporting_unit = bq.dim_reporting_unit) AND (tab_ru.dim_year = bq.dim_year) AND (tab_ru.dim_destination = bq.dim_destination) AND (tab_ru.dim_reporting_category = bq.dim_reporting_category)))
) 
, tab_cat AS (
   SELECT
     *
   , sum(kpi_rel) OVER (PARTITION BY dim_year, dim_destination, dim_reporting_category, dim_reporting_unit ORDER BY kpi_rel DESC) kpi_cumsum
   FROM
     tab_rel
   ORDER BY dim_year ASC, dim_destination ASC, dim_reporting_category ASC, dim_reporting_unit ASC, kpi_rel DESC
) 
, tab_fin AS (
   SELECT
     *
   , (CASE WHEN (kpi_cumsum <= DECIMAL '0.8') THEN 'A' WHEN (kpi_cumsum <= DECIMAL '0.95') THEN 'B' ELSE 'C' END) kpi_cat_ABC
   , (CASE WHEN (kpi_cv <= DECIMAL '0.5') THEN 'X' WHEN (kpi_cv <= 1) THEN 'Y' ELSE 'Z' END) kpi_cat_XYZ
   FROM
     tab_cat
) 
SELECT
  dim_year
, dim_material
, dim_destination
, dim_reporting_category
, dim_reporting_unit
, kpi_cat_ABC
, kpi_cat_XYZ
FROM
  tab_fin