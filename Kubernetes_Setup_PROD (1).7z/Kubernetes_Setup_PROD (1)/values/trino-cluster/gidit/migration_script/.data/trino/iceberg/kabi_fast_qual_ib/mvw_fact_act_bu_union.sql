CREATE TABLE iceberg.kabi_fast_qual_ib.mvw_fact_act_bu_union (
   dim_date date,
   dim_measure varchar,
   dim_version varchar,
   dim_lag bigint,
   dim_month bigint,
   dim_destination varchar,
   dim_reporting_category varchar,
   dim_material varchar,
   dim_local_currency varchar,
   dim_estimation varchar,
   dim_batch varchar,
   dim_currency_type varchar,
   dim_source_system varchar,
   dim_sales_territory varchar,
   dim_sales_channel varchar,
   kpi double,
   dim_reporting_unit varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/mvw_fact_act_bu_union__dbt_tmp-846d7027aa6344f5adab430e0afdcb74'
)