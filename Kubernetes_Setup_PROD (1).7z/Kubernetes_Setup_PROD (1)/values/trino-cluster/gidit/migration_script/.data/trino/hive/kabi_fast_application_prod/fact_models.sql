CREATE TABLE hive.kabi_fast_application_prod.fact_models (
   dim_ts_key varchar,
   dim_date date,
   arima double,
   ets double,
   snaive double,
   rw_t double,
   prophet double,
   theta double,
   actuals double,
   dim_last_act date,
   dim_reporting_unit varchar
)
WITH (
   external_location = 's3a://fast/presto_application/prod/fact_models',
   format = 'PARQUET',
   partitioned_by = ARRAY['dim_reporting_unit']
)