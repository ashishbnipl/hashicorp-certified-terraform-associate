CREATE VIEW iceberg.kabi_fast_qual_ib."vw_dim_reporting_unit" SECURITY DEFINER AS
SELECT *
FROM
  "iceberg"."kabi_fast_qual_ib"."dim_reporting_unit"
WHERE (NOT (dim_reporting_unit IN (SELECT dim_reporting_unit
FROM
  "iceberg"."kabi_fast_qual_ib"."vw_ru_old"
)))