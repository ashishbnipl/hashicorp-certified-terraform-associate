CREATE TABLE iceberg.kabi_fast_prod_ib.mvw_batch_gsis (
   dim_model varchar,
   dim_batch varchar,
   dim_reporting_unit varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-prod/iceberg/mvw_batch_gsis__dbt_tmp-7f8627ca398a43eb8cf0a4d48725a42d'
)