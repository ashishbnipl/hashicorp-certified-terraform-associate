CREATE TABLE hive.kabi_fast_test.fact_act_bu (
   dim_measure varchar,
   dim_material varchar,
   dim_destination varchar,
   dim_reporting_category varchar,
   kpi double,
   dim_local_currency varchar,
   dim_currency_type varchar,
   dim_version varchar,
   dim_date date,
   dim_sales_channel varchar,
   dim_sales_territory varchar,
   dim_source_system varchar,
   dim_reporting_unit varchar
)
WITH (
   external_location = 's3a://fast/presto/test/fact_act_bu',
   format = 'PARQUET',
   partitioned_by = ARRAY['dim_reporting_unit']
)