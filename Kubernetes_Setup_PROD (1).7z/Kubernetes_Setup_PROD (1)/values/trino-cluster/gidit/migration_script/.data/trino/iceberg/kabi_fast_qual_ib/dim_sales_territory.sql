CREATE TABLE iceberg.kabi_fast_qual_ib.dim_sales_territory (
   dim_sales_territory varchar,
   sales_territory_text varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/dim_sales_territory-0f1dd63ea06d41f68f52aac6f55c1764'
)