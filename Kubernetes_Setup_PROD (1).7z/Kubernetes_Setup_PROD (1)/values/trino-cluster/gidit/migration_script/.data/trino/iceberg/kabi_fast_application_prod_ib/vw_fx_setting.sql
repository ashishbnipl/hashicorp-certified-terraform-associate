CREATE VIEW iceberg.kabi_fast_application_prod_ib."vw_fx_setting" SECURITY DEFINER AS
WITH
  bq AS (
   SELECT
     *
   , min(dim_month) OVER (PARTITION BY dim_view) min_dim_month
   , max(dim_month) OVER (PARTITION BY dim_view) max_dim_month
   , max(dim_lag) OVER (PARTITION BY dim_view) max_dim_lag
   FROM
     iceberg.kabi_fast_application_prod_ib.vw_period_setting
   WHERE (dim_version = 'AVA')
) 
SELECT
  (CASE WHEN ((min_dim_month <= 1) AND (max_dim_month = 12) AND (max_dim_lag <= 12) AND (NOT (dim_view LIKE '%Budget%'))) THEN 'BUD' WHEN ((min_dim_month <= 6) AND (max_dim_month = 12) AND (max_dim_lag <= 12) AND (NOT (dim_view LIKE '%Budget%'))) THEN 'FC0FIN' WHEN ((min_dim_month <= 9) AND (max_dim_month = 12) AND (max_dim_lag <= 12) AND (NOT (dim_view LIKE '%Budget%'))) THEN 'FC2' WHEN ((min_dim_month <= 12) AND (max_dim_month = 12) AND (max_dim_lag <= 12) AND (NOT (dim_view LIKE '%Budget%'))) THEN 'FC3' WHEN ((max_dim_lag <= 15) AND (dim_view = 'Full-Year Budget Y1')) THEN 'BUDY1' WHEN ((max_dim_lag <= 27) AND (dim_view = 'Full-Year Budget Y2')) THEN 'BUDY2' WHEN ((max_dim_lag <= 39) AND (dim_view = 'Full-Year Budget Y3')) THEN 'BUDY3' END) dim_version
, dim_month
, dim_lag
FROM
  bq