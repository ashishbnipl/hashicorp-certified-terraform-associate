CREATE TABLE iceberg.kabi_fast_qual_ib.mvw_fact_act_bu_agg (
   dim_date date,
   dim_measure varchar,
   dim_estimation varchar,
   dim_local_currency varchar,
   dim_batch varchar,
   dim_source_system varchar,
   kpi double,
   dim_reporting_unit varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/mvw_fact_act_bu_agg__dbt_tmp-a4f261bba062409c8846f349708d3191'
)