CREATE VIEW iceberg.kabi_fast_prod_ib."vw_merged" SECURITY DEFINER AS
WITH
  bq AS (
   SELECT
     dim_reporting_unit
   , dim_date
   , dim_measure
   , dim_material
   , dim_destination
   , dim_local_currency
   , dim_reporting_category
   , dim_source_system
   , dim_sales_territory
   , dim_sales_channel
   , dim_view
   , dim_type
   , max_act_month_scenario
   , dim_version
   , kpi
   , flag_pred_fill_up
   , dim_year
   , dim_month
   FROM
     "iceberg"."kabi_fast_prod_ib"."mvw_minmax"
UNION ALL    SELECT
     dim_reporting_unit
   , dim_date
   , dim_measure
   , dim_material
   , dim_destination
   , dim_local_currency
   , dim_reporting_category
   , dim_source_system
   , dim_sales_territory
   , dim_sales_channel
   , dim_view
   , dim_type
   , max_act_month_scenario
   , dim_version
   , kpi
   , flag_pred_fill_up
   , dim_year
   , dim_month
   FROM
     "iceberg"."kabi_fast_prod_ib"."mvw_fill_up"
) 
SELECT *
FROM
  bq