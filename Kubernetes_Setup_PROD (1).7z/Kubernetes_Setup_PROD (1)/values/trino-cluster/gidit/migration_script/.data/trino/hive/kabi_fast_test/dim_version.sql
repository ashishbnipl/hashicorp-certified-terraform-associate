CREATE TABLE hive.kabi_fast_test.dim_version (
   dim_version varchar,
   version_group varchar,
   version_name varchar,
   ordering integer
)
WITH (
   external_location = 's3a://fast/presto/test/dim_version',
   format = 'PARQUET'
)