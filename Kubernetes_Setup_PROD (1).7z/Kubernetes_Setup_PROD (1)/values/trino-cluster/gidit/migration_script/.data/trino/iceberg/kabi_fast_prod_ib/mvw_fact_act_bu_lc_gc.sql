CREATE TABLE iceberg.kabi_fast_prod_ib.mvw_fact_act_bu_lc_gc (
   dim_date date,
   dim_measure varchar,
   dim_version varchar,
   dim_lag bigint,
   dim_month bigint,
   dim_destination varchar,
   dim_reporting_category varchar,
   dim_material varchar,
   dim_local_currency varchar,
   dim_estimation varchar,
   dim_batch varchar,
   dim_sales_territory varchar,
   dim_sales_channel varchar,
   dim_source_system varchar,
   kpi double,
   dim_reporting_unit varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-prod/iceberg/mvw_fact_act_bu_lc_gc__dbt_tmp-cd23346041684caba89f1395abe09f60'
)