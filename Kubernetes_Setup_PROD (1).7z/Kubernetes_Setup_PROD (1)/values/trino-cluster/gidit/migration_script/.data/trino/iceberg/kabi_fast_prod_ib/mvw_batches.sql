CREATE TABLE iceberg.kabi_fast_prod_ib.mvw_batches (
   dim_model varchar,
   dim_batch varchar,
   dim_reporting_unit varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-prod/iceberg/mvw_batches__dbt_tmp-7e044403b4c845ad864967b27e0e1778'
)