CREATE TABLE hive.kabi_fast_qual.raw_dim_reporting_unit_text (
   dim_reporting_unit varchar
)
WITH (
   format = 'PARQUET'
)