CREATE VIEW iceberg.kabi_fast_application_prod_ib."vw_fact_act_bu" SECURITY DEFINER AS
WITH
  bq_union AS (
   SELECT
     dim_measure
   , dim_material
   , dim_reporting_unit
   , dim_destination
   , dim_reporting_category
   , kpi
   , dim_local_currency
   , dim_currency_type
   , dim_version
   , dim_date
   FROM
     iceberg.kabi_fast_application_prod_ib.fact_act_bu
UNION ALL    SELECT
     dim_measure
   , dim_material
   , dim_reporting_unit
   , dim_destination
   , dim_reporting_category
   , kpi
   , dim_local_currency
   , dim_currency_type
   , dim_version
   , dim_date
   FROM
     iceberg.kabi_fast_application_prod_ib.fact_bud23
) 
, bq AS (
   SELECT
     dat.dim_reporting_unit
   , dat.dim_date
   , dat.dim_measure
   , dat.dim_material
   , dat.dim_version
   , EXTRACT(MONTH FROM dat.dim_date) dim_month
   , dat.dim_destination
   , dat.dim_local_currency
   , dat.dim_reporting_category
   , dat.dim_currency_type
   , dat.kpi
   , mat.l3
   , mat.l4
   , mat.l5
   , mat.l6
   , mat.l7
   , (CASE WHEN (dat.dim_version = 'BUDY1') THEN 9 WHEN (dat.dim_version = 'BUDY2') THEN 9 WHEN (dat.dim_version = 'BUDY3') THEN 9 WHEN (dat.dim_version = 'BUD') THEN 12 WHEN (dat.dim_version = 'FC0FIN') THEN 1 WHEN (dat.dim_version = 'FC2') THEN 6 WHEN (dat.dim_version = 'FC3') THEN 9 ELSE null END) dim_periods
   FROM
     (bq_union dat
   LEFT JOIN iceberg.kabi_fast_application_prod_ib.dim_material mat ON (dat.dim_material = mat.dim_material))
   WHERE ((dat.dim_version = 'ACT') OR ((dat.dim_version <> 'ACT') AND (dat.dim_date >= CAST('2017-01-01' AS date))))
) 
, bq2 AS (
   SELECT
     dim_reporting_unit
   , dim_date
   , dim_measure
   , dim_version
   , (CASE WHEN (dim_version = 'ACT') THEN 0 WHEN (dim_version = 'BUDY1') THEN (dim_month + 3) WHEN (dim_version = 'BUDY2') THEN (dim_month + 15) WHEN (dim_version = 'BUDY3') THEN (dim_month + 27) WHEN ((dim_month - dim_periods) > 0) THEN (dim_month - dim_periods) ELSE ((12 + dim_month) - dim_periods) END) dim_lag
   , dim_month
   , dim_destination
   , dim_reporting_category
   , dim_material
   , dim_local_currency
   , l7 dim_estimation
   , dim_currency_type
   , kpi
   FROM
     bq
) 
, tab_ns_lc AS (
   SELECT
     dim_reporting_unit
   , dim_date
   , dim_measure
   , dim_version
   , dim_lag
   , dim_month
   , dim_destination
   , dim_reporting_category
   , dim_material
   , dim_local_currency
   , dim_estimation
   , kpi
   FROM
     bq2
   WHERE ((dim_measure = 'NS') AND (dim_currency_type = 'LC'))
) 
, tab_gc AS (
   SELECT
     dim_reporting_unit
   , dim_date
   , dim_measure
   , dim_version
   , dim_lag
   , dim_month
   , dim_destination
   , dim_reporting_category
   , dim_material
   , (CASE WHEN (dim_measure = 'NS') THEN 'GC' ELSE dim_measure END) dim_local_currency
   , dim_estimation
   , kpi
   FROM
     bq2
   WHERE (dim_currency_type = 'GC')
) 
, tab_union AS (
   SELECT
     dim_reporting_unit
   , dim_date
   , dim_measure
   , dim_version
   , dim_lag
   , dim_month
   , dim_destination
   , dim_reporting_category
   , dim_material
   , dim_local_currency
   , dim_estimation
   , kpi
   FROM
     tab_ns_lc
UNION ALL    SELECT
     dim_reporting_unit
   , dim_date
   , dim_measure
   , dim_version
   , dim_lag
   , dim_month
   , dim_destination
   , dim_reporting_category
   , dim_material
   , dim_local_currency
   , dim_estimation
   , kpi
   FROM
     tab_gc
) 
SELECT *
FROM
  tab_union