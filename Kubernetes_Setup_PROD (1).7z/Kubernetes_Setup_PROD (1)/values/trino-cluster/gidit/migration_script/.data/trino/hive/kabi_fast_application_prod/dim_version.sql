CREATE TABLE hive.kabi_fast_application_prod.dim_version (
   dim_version varchar,
   version_group varchar,
   version_name varchar,
   ordering bigint
)
WITH (
   external_location = 's3a://fast/presto_application/prod/dim_version',
   format = 'PARQUET'
)