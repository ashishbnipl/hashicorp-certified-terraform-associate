CREATE TABLE hive.kabi_fast_qual.raw_dim_sales_territory (
   dim_sales_territory varchar,
   sales_territory_text varchar
)
WITH (
   format = 'PARQUET'
)