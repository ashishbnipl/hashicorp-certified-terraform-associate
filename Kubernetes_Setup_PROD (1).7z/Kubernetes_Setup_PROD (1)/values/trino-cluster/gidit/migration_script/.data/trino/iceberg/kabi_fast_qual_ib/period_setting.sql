CREATE TABLE iceberg.kabi_fast_qual_ib.period_setting (
   dim_view varchar,
   dim_type varchar,
   dim_month integer,
   dim_version varchar,
   dim_lag integer
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/period_setting-ff127872bb7244fc99327fcf706abca4'
)