CREATE TABLE iceberg.kabi_fast_qual_ib.mvw_fact_reporting (
   dim_date date,
   dim_year bigint,
   dim_month integer,
   dim_view varchar,
   dim_measure varchar,
   dim_material varchar,
   dim_reporting_unit varchar,
   dim_local_currency varchar,
   dim_destination varchar,
   dim_reporting_category varchar,
   dim_sales_channel varchar,
   dim_sales_territory varchar,
   dim_source_system varchar,
   dim_type varchar,
   dim_version varchar,
   kpi double,
   max_act_month_scenario bigint,
   flag_pred_fill_up integer,
   kpi_cat_abc varchar,
   kpi_cat_xyz varchar,
   flag_asp varchar,
   flag_current_fy_scenario integer,
   flag_leq_max_date_act integer,
   flag_cy_acc boolean
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/mvw_fact_reporting__dbt_tmp-f93c6c5572b24412b550539e2b435a4b'
)