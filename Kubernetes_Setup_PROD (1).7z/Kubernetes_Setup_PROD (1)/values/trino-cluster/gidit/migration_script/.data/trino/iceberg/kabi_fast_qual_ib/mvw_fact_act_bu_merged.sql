CREATE TABLE iceberg.kabi_fast_qual_ib.mvw_fact_act_bu_merged (
   dim_measure varchar,
   dim_material varchar,
   dim_reporting_unit varchar,
   dim_destination varchar,
   dim_reporting_category varchar,
   kpi double,
   dim_local_currency varchar,
   dim_currency_type varchar,
   dim_version varchar,
   dim_source_system varchar,
   dim_sales_territory varchar,
   dim_sales_channel varchar,
   dim_date date
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/mvw_fact_act_bu_merged__dbt_tmp-8b7cf5bf38c147a2acf3e782e96fd7d5'
)