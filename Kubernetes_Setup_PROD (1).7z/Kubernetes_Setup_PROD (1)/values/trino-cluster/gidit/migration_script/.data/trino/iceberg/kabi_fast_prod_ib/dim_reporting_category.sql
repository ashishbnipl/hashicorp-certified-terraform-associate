CREATE TABLE iceberg.kabi_fast_prod_ib.dim_reporting_category (
   dim_reporting_category varchar,
   reporting_category_name varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-prod/iceberg/dim_reporting_category-f0d930312b36492f8c681590c3e599c8'
)