CREATE TABLE hive.kabi_fast_qual.raw_dim_version (
   dim_version varchar,
   version_group varchar,
   version_name varchar,
   ordering integer
)
WITH (
   format = 'PARQUET'
)