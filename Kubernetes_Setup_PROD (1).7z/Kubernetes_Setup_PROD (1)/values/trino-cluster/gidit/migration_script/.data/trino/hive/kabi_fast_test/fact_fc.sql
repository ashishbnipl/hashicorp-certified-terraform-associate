CREATE TABLE hive.kabi_fast_test.fact_fc (
   dim_date date,
   dim_measure varchar,
   dim_estimation varchar,
   dim_local_currency varchar,
   dim_version varchar,
   kpi double,
   dim_last_act date,
   dim_source_system varchar,
   dim_reporting_unit varchar
)
WITH (
   external_location = 's3a://fast/presto/test/fact_fc',
   format = 'PARQUET'
)