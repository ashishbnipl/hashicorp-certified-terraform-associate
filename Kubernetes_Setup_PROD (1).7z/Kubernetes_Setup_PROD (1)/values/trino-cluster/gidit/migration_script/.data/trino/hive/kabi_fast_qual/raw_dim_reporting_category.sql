CREATE TABLE hive.kabi_fast_qual.raw_dim_reporting_category (
   dim_reporting_category varchar,
   reporting_category_name varchar
)
WITH (
   format = 'PARQUET'
)