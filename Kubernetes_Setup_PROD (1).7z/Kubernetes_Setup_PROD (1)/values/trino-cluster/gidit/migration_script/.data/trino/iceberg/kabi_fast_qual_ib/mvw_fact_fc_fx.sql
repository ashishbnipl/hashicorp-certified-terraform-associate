CREATE TABLE iceberg.kabi_fast_qual_ib.mvw_fact_fc_fx (
   dim_date date,
   dim_measure varchar,
   dim_estimation varchar,
   dim_version varchar,
   dim_local_currency varchar,
   dim_lag bigint,
   dim_month bigint,
   kpi double,
   dim_reporting_unit varchar,
   dim_source_system varchar,
   dim_last_act date,
   max_dim_last_act date
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/mvw_fact_fc_fx__dbt_tmp-82b443e3debe4c949488557184d9935d'
)