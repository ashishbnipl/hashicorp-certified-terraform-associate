CREATE TABLE iceberg.kabi_fast_qual_ib.mvw_batch_gsis (
   dim_model varchar,
   dim_batch varchar,
   dim_reporting_unit varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/mvw_batch_gsis__dbt_tmp-bf568453fdb84c26a5d3bbb205c9dbc7'
)