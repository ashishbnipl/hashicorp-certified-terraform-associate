CREATE VIEW iceberg.kabi_fast_prod_ib."vw_period_setting" SECURITY DEFINER AS
WITH
  dw AS (
   SELECT DISTINCT dim_view
   FROM
     "iceberg"."kabi_fast_prod_ib"."period_setting"
) 
, dm AS (
   SELECT DISTINCT DIM_MONTH
   FROM
     "iceberg"."kabi_fast_prod_ib"."period_setting"
) 
, act AS (
   SELECT
     dw.dim_view
   , 'Actuals' dim_type
   , dm.dim_month
   , 'ACT' dim_version
   , 0 dim_lag
   FROM
     (dw
   FULL JOIN dm ON (1 = 1))
) 
, tab_union AS (
   SELECT
     dim_view
   , dim_type
   , dim_month
   , dim_version
   , dim_lag
   FROM
     act
UNION ALL    SELECT
     dim_view
   , dim_type
   , dim_month
   , dim_version
   , dim_lag
   FROM
     "iceberg"."kabi_fast_prod_ib"."period_setting"
) 
, tab_union2 AS (
   SELECT
     *
   , (CASE WHEN ((SELECT EXTRACT(MONTH FROM max(dim_date))
FROM
  "iceberg"."kabi_fast_prod_ib"."fact_act_bu"
WHERE (dim_version = 'ACT')
) = 12) THEN 0 ELSE (SELECT EXTRACT(MONTH FROM max(dim_date))
FROM
  "iceberg"."kabi_fast_prod_ib"."fact_act_bu"
WHERE (dim_version = 'ACT')
) END) dim_period
   FROM
     tab_union
) 
, tab_flagged AS (
   SELECT
     *
   , (CASE WHEN (NOT (dim_view IN ('Full-Year January', 'Full-Year Budget Y1', 'Full-Year Budget Y2', 'Full-Year Budget Y3'))) THEN max((CASE WHEN ((dim_type <> 'Actuals') AND (dim_version = 'ACT')) THEN dim_month END)) OVER (PARTITION BY dim_view) WHEN (dim_view = 'Full-Year January') THEN 0 WHEN ((dim_type = 'Bottom-Up') AND (dim_view IN ('Full-Year Budget Y1', 'Full-Year Budget Y2', 'Full-Year Budget Y3'))) THEN 9 ELSE dim_period END) max_act_month_scenario
   , (CASE WHEN (dim_view LIKE 'Full-Year%%') THEN 1 ELSE 0 END) flag_download
   FROM
     tab_union2
) 
SELECT
  dim_view
, dim_type
, dim_month
, dim_version
, (CASE WHEN ((dim_type = 'Predictive') AND (dim_view = 'Full-Year Budget Y1') AND ((dim_period - max_act_month_scenario) <= 0)) THEN 0 WHEN ((dim_type = 'Predictive') AND (dim_view = 'Full-Year Budget Y1') AND ((dim_period - max_act_month_scenario) > 0)) THEN ((0 * 12) + (dim_month - max_act_month_scenario)) WHEN ((dim_type = 'Predictive') AND (dim_view = 'Full-Year Budget Y2')) THEN ((1 * 12) + (dim_month - max_act_month_scenario)) WHEN ((dim_type = 'Predictive') AND (dim_view = 'Full-Year Budget Y3')) THEN ((2 * 12) + (dim_month - max_act_month_scenario)) ELSE dim_lag END) dim_lag
, max_act_month_scenario
, flag_download
FROM
  tab_flagged