CREATE TABLE hive.kabi_fast_application_prod.dim_reporting_category (
   dim_reporting_category varchar,
   reporting_category_name varchar
)
WITH (
   external_location = 's3a://fast/presto_application/prod/dim_reporting_category',
   format = 'PARQUET'
)