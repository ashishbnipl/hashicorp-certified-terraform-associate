CREATE TABLE iceberg.kabi_fast_prod_ib.dim_version (
   dim_version varchar,
   version_group varchar,
   version_name varchar,
   ordering integer
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-prod/iceberg/dim_version-fd8c2b2e519f4ceea715995cc6fd4c86'
)