CREATE TABLE iceberg.kabi_fast_prod_ib.dim_destination (
   dim_destination varchar,
   destination_name varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-prod/iceberg/dim_destination-59f1c23ac27d4e3abfb2c0256288648e'
)