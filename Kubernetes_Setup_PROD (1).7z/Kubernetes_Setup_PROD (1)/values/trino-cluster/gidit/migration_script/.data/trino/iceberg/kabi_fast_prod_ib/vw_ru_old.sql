CREATE VIEW iceberg.kabi_fast_prod_ib."vw_ru_old" SECURITY DEFINER AS
WITH
  bq AS (
   SELECT
     dim_reporting_unit
   , round(sum(kpi)) kpi
   , (EXTRACT(YEAR FROM dim_date) < 2022) flag_year
   FROM
     "iceberg"."kabi_fast_prod_ib"."fact_act_bu"
   WHERE ((dim_measure = 'NS') AND (dim_version = 'ACT'))
   GROUP BY dim_reporting_unit, (EXTRACT(YEAR FROM dim_date) < 2022)
) 
, tab2 AS (
   SELECT
     dim_reporting_unit
   , flag_year
   , kpi
   , (CASE WHEN ((flag_year AND (kpi > 0)) OR ((NOT flag_year) AND (kpi = 0))) THEN 1 ELSE 0 END) flag_2
   FROM
     bq
) 
SELECT dim_reporting_unit
FROM
  tab2
GROUP BY dim_reporting_unit
HAVING (sum(flag_2) = 2)