CREATE TABLE iceberg.kabi_fast_qual_ib.dim_destination (
   dim_destination varchar,
   destination_name varchar
)
WITH (
   format = 'PARQUET',
   format_version = 2,
   location = 's3a://kabi-fast-qual/iceberg/dim_destination-a32763e310994e6185bd8e50e8c74110'
)