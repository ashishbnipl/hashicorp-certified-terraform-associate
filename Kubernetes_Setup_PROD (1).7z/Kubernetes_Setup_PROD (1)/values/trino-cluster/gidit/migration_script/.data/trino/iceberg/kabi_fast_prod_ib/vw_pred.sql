CREATE VIEW iceberg.kabi_fast_prod_ib."vw_pred" SECURITY DEFINER AS
WITH
  tab_pred AS (
   SELECT
     tab_restrict_pred.dim_reporting_unit
   , tab_restrict_pred.dim_date
   , tab_restrict_pred.dim_measure
   , tab_restrict_pred.dim_material
   , tab_restrict_pred.dim_local_currency
   , tab_restrict_pred.dim_version
   , tab_restrict_pred.dim_destination
   , tab_restrict_pred.dim_reporting_category
   , tab_restrict_pred.dim_source_system
   , tab_restrict_pred.dim_sales_channel
   , tab_restrict_pred.dim_sales_territory
   , tab_restrict_pred.kpi
   , ps.dim_type
   , ps.max_act_month_scenario
   , ps.dim_month
   , tab_restrict_pred.dim_year
   , ps.dim_view
   FROM
     ("iceberg"."kabi_fast_prod_ib"."mvw_fact_restricted_pred" tab_restrict_pred
   INNER JOIN "iceberg"."kabi_fast_prod_ib"."vw_period_setting" ps ON ((tab_restrict_pred.dim_version = ps.dim_version) AND (tab_restrict_pred.dim_month = ps.dim_month) AND (tab_restrict_pred.dim_lag = ps.dim_lag)))
   WHERE ((1 = 1) AND (EXTRACT(YEAR FROM dim_date) >= 2022))
) 
SELECT *
FROM
  tab_pred