CREATE TABLE hive.kabi_fast_dev.raw_dim_material (
   dim_material varchar,
   material_name varchar,
   l3_name varchar,
   l4_name varchar,
   l5_name varchar,
   l6_name varchar,
   l7_name varchar,
   l8_name varchar,
   l9_name varchar,
   l3 varchar,
   l4 varchar,
   l5 varchar,
   l6 varchar,
   l7 varchar,
   l8 varchar,
   l9 varchar,
   base_uom varchar
)
WITH (
   format = 'PARQUET'
)