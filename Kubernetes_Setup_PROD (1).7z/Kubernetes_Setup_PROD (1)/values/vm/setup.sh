#terraform
sudo apt-get update && sudo apt-get install -y gnupg software-properties-common postgresql postgresql-contrib
wget -O- https://apt.releases.hashicorp.com/gpg | \
gpg --dearmor | \
sudo tee /usr/share/keyrings/hashicorp-archive-keyring.gpg
gpg --no-default-keyring \
--keyring /usr/share/keyrings/hashicorp-archive-keyring.gpg \
--fingerprint
echo "deb [signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] \
https://apt.releases.hashicorp.com $(lsb_release -cs) main" | \
sudo tee /etc/apt/sources.list.d/hashicorp.list
sudo apt update
sudo apt-get install terraform

#az
sudo curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash

#git,network tools
sudo apt-get install -y git telnet netcat curl unzip build-essential

#kubectl
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl

#kubelogin
sudo wget https://github.com/Azure/kubelogin/releases/download/v0.0.28/kubelogin-linux-amd64.zip
sudo unzip kubelogin-linux-amd64.zip
sudo mv ~/bin/linux_amd64/kubelogin /bin/
sudo rm kubelogin-linux-amd64.zip
sudo rm LICENSE
sudo rm README.md
sudo rm -rf bin

#k9s
sudo wget https://github.com/derailed/k9s/releases/download/v0.27.3/k9s_Linux_amd64.tar.gz
sudo tar -xvf k9s_Linux_amd64.tar.gz
sudo mv k9s /bin/
sudo rm LICENSE
sudo rm README.md
sudo rm k9s_Linux_amd64.tar.gz

#mc
sudo curl https://dl.min.io/client/mc/release/linux-amd64/archive/mc.RELEASE.2020-11-25T23-04-07Z \
  --create-dirs \
  -o $HOME/minio-binaries/mc

sudo mkdir $HOME/minio-binaries/mc
sudo chmod +x $HOME/minio-binaries/mc
export PATH=$PATH:$HOME/minio-binaries/
echo "export PATH=$PATH:$HOME/minio-binaries/" >> ~/.bashrc




