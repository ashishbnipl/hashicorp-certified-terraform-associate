# Open Items
- [ ] Enable Role Based Access to ETCD again (23.06.2020 - did not work last night)
- [ ] Ensure main storage account is setup to include this multi user setup
- [ ] Checkpoint ETCD to blob storage as backup (enable settings) (this this can only work with NFS a snapshot target, that might work as well)
- [ ] Enable metrics and grafana visibility of etcd endpoint