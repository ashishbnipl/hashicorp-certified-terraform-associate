# Step 1

- provision the storage account and the vm for terraforming and bootstrapping the whole project 
- unfortunatly the network etc. needs to be setup here as well as we need to align storage account with the network 
- keyvault is included as well but doe not necessarily be that way
